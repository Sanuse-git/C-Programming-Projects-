# PRG161 Milestone 2: Flourish & Blotts Magical Cash Register

**Student submission package:** C# console application for the loyalty rental system.

> **Important before submission:** Replace the group-member placeholders in `Program.cs` and in the contribution table below. The application is intentionally written so that a beginner can read, explain, and improve it during the project defense.

## 1. Project overview

This project is a console-based magical book-rental system for Flourish & Blotts. It allows the shop to register customers, add books to its inventory, rent several books in one transaction, and complete checkout. The program also demonstrates the loyalty-program features from the brief: time-based discounts, rental coupons, and Room of Requirement rewards.

I chose a console application because the milestone focuses on programming fundamentals rather than graphical design. A console program makes the input, processing, and output easy to follow. It also made it possible to concentrate on the required ideas: enums, methods, loops, lists, validation, and accurate price calculations.

## 2. Requirements covered

| Assignment requirement | Where it is implemented |
|---|---|
| C# console application | `FlourishAndBlotts.csproj` and `Program.cs` |
| Enum-based menus | `MainMenuOption` and `RentalMenuOption` |
| Enter new customers | `AddCustomer()` |
| Add new books | `AddBook()` |
| Rent multiple books | `StartRental()` and `RentalMenuOption.AddAnotherBook` |
| Track rentals and total cost | `Customer.TotalRentals`, `Customer.LifetimeSpend`, and `RentalLine` |
| Time-based discount | `CalculateTimeDiscount()` |
| Rental-based coupons | `CalculateCouponDiscount()` and `CalculateCouponsEarned()` |
| Magical bonuses | `DisplayMagicalBonus()` |
| Checkout receipt | `Checkout()` |
| Multiple customers | Main `while` loop and customer list |
| Reset cart after checkout | `cart.Clear()` |
| Exit option | `MainMenuOption.Exit` |
| Modular methods | Small methods for menus, input, calculations, display, and checkout |
| Comments explaining code | Comments above important logic blocks in `Program.cs` |

## 3. Research used in the design

The menu design uses C# enumeration types. Microsoft explains that an enum is a value type made from named constants, which makes it suitable for a fixed set of choices such as `AddCustomer`, `AddBook`, and `Exit` [1]. This is clearer than scattering unexplained numbers throughout the program.

The program stores customers, books, and rental lines in `List<T>` collections. Microsoft describes `List<T>` as a strongly typed list that supports adding, searching, and manipulating objects [2]. A list is appropriate here because the shop can receive new customers and books while the program is running.

The time discount uses `DateTime.Now` and checks the current hour. Microsoft’s .NET guidance distinguishes date/time values from time intervals and explains that date and time types can be used for date arithmetic and comparisons [3]. This supports the decision to keep the discount calculation in a separate method that receives a `DateTime` value.

## 4. Business rules used in this version

The brief names the required loyalty features but does not prescribe exact percentages or thresholds. I therefore selected simple rules that can be demonstrated and explained easily:

| Rule | Behaviour |
|---|---|
| Evening discount | A 10% discount applies when checkout happens at 18:00 or later. |
| Rental coupon | Every third rental activates a 5% coupon discount on that checkout. |
| Coupon display | The customer earns one loyalty coupon for every three total rentals. |
| Magical bonus | Renting two or more magical books awards a bonus book; one magical book awards a silver bookmark. |
| Price protection | The total cannot become negative because `Math.Max` is used. |

These rules are examples for the milestone. If the lecturer or the group's Milestone 1 specification provides different business rules, the percentages and thresholds should be changed in the calculation methods rather than throughout the whole program.

## 5. Program structure

The program uses four small data classes. `Customer` stores the customer's name, number of rentals, and lifetime spending. `Book` stores inventory information. `RentalLine` represents one book in the current cart and records when it was added. The `Program` class contains the menu loop and reusable methods.

The main menu is controlled by a `while` loop. This means the application does not close after one customer. The rental menu has its own loop so that several books can be placed in one cart. Once checkout finishes, the same cart is cleared. The customer record is updated only after the checkout calculations have been displayed.

Input validation is handled with methods such as `ReadInteger`, `ReadDecimal`, `ReadText`, and `ReadYesNo`. This avoids repeating the same validation code in several menu methods. It also prevents common beginner errors such as accepting an empty customer name or a negative rental price.

## 6. Testing plan and expected results

| Test | Input idea | Expected result |
|---|---|---|
| Add customer | Add `Hermione Granger` | Customer appears in the customer list. |
| Add book | Add a book with a positive price | Book appears in inventory with a new ID. |
| Multiple-book cart | Rent two different books, choose “Add another book” | Both titles appear on the checkout receipt. |
| Evening discount | Run checkout at or after 18:00 | The receipt shows a 10% time discount. |
| Coupon threshold | Complete enough rentals for the customer's total to reach three | A 5% rental coupon and earned coupon message are shown. |
| Magical reward | Rent two magical books | The Room of Requirement bonus book is displayed. |
| Cart reset | Checkout, then start another rental | The new cart starts empty. |
| Invalid input | Enter letters where a number is required | The program asks for a valid number instead of crashing. |
| Exit | Choose 0 on the main menu | The application closes with a message. |

## 7. Known limitations and possible improvements

This version stores data in memory, so customers and books disappear when the application closes. A later version could save the data to a text file or a database. The system also does not track whether a book is currently available, because the milestone focuses on the shopping and loyalty logic. A fuller system could add stock quantities, return dates, late fees, staff logins, and a proper receipt number.

Another improvement would be to inject the current time into the program during testing. The current solution already keeps the time calculation in `CalculateTimeDiscount`, which makes that improvement easier. A test version could pass a chosen time instead of always using `DateTime.Now`.

## 8. Group contribution record

| Group member | Contribution to this milestone |
|---|---|
| Member 1: replace with name | Replace with the actual agreed contribution. |
| Member 2: replace with name | Replace with the actual agreed contribution. |
| Member 3: replace with name | Replace with the actual agreed contribution. |
| Member 4: replace with name, if applicable | Replace with the actual agreed contribution. |

Every group member should understand the entire program because the brief states that the defense can question each member on the whole project.

## 9. How to run

Install the .NET 8 SDK, open a terminal in this folder, and run:

```bash
dotnet run
```

To build without running:

```bash
dotnet build
```

## 10. Five-minute defense outline

First, explain that the application models a small book-rental shop. Then demonstrate the main enum menu by adding a customer and viewing the inventory. Start a rental, add two books, and explain that the rental loop keeps accepting books until checkout is selected. During checkout, point out the subtotal, time discount, rental coupon, total due, and magical bonus.

Next, explain the most important methods. `CalculateTimeDiscount` handles the time rule, `CalculateCouponDiscount` handles the every-third-rental rule, and `DisplayMagicalBonus` checks how many magical books were rented. Finally, show that `cart.Clear()` resets the cart and that the outer `while` loop returns to the main menu for another customer.

Likely questions include: “Why use an enum?”, “Why use a list?”, “How does the cart reset?”, “When is the customer updated?”, and “How would you save data after the program closes?” The short answers are: enums make fixed menu choices readable, lists hold a changing number of objects, `cart.Clear()` empties the cart, the customer updates after successful checkout, and file or database storage could be added in a future version.

## References

[1]: https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/enum "Enumeration types - C# reference"
[2]: https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.list-1?view=net-10.0 "List<T> Class"
[3]: https://learn.microsoft.com/en-us/dotnet/standard/datetime/ "Date, time, and time zones"

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace FlourishAndBlotts
{
    // PRG161 Milestone 2
    // Group members: Replace these placeholders with your actual group members.
    // Contribution record: Each member should update the contribution section in README.md.

    public enum MainMenuOption
    {
        Exit = 0,
        AddCustomer = 1,
        AddBook = 2,
        StartRental = 3,
        ViewCustomers = 4,
        ViewBooks = 5
    }

    public enum RentalMenuOption
    {
        Checkout = 0,
        AddAnotherBook = 1,
        CancelRental = 2
    }

    public class Customer
    {
        public string Name { get; set; }
        public int TotalRentals { get; set; }
        public decimal LifetimeSpend { get; set; }

        public Customer(string name)
        {
            Name = name;
            TotalRentals = 0;
            LifetimeSpend = 0m;
        }
    }

    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public decimal RentalPrice { get; set; }
        public bool IsMagical { get; set; }

        public Book(int id, string title, string author, decimal rentalPrice, bool isMagical)
        {
            Id = id;
            Title = title;
            Author = author;
            RentalPrice = rentalPrice;
            IsMagical = isMagical;
        }
    }

    public class RentalLine
    {
        public Book Book { get; set; }
        public DateTime RentedAt { get; set; }

        public RentalLine(Book book)
        {
            Book = book;
            RentedAt = DateTime.Now;
        }
    }

    public class Program
    {
        private static readonly List<Customer> Customers = new List<Customer>();
        private static readonly List<Book> Books = new List<Book>();
        private static int nextBookId = 1;

        public static void Main()
        {
            SeedBooks();
            AddDemoCustomer();

            bool keepRunning = true;
            Console.Title = "Flourish & Blotts Magical Cash Register";

            while (keepRunning)
            {
                PrintHeading("FLOURISH & BLOTTS");
                Console.WriteLine("Welcome to the magical cash register.\n");
                MainMenuOption choice = ReadMainMenuOption();

                switch (choice)
                {
                    case MainMenuOption.AddCustomer:
                        AddCustomer();
                        break;
                    case MainMenuOption.AddBook:
                        AddBook();
                        break;
                    case MainMenuOption.StartRental:
                        StartRental();
                        break;
                    case MainMenuOption.ViewCustomers:
                        DisplayCustomers();
                        break;
                    case MainMenuOption.ViewBooks:
                        DisplayBooks();
                        break;
                    case MainMenuOption.Exit:
                        keepRunning = false;
                        Console.WriteLine("The register is closing. Have a magical day!");
                        break;
                }

                if (keepRunning)
                {
                    Pause();
                }
            }
        }

        // Seed data makes the application usable immediately during a demonstration.
        private static void SeedBooks()
        {
            AddBookToInventory("Advanced Potion-Making", "Libatius Borage", 35.00m, true);
            AddBookToInventory("A Beginner's Guide to Transfiguration", "Emeric Switch", 28.50m, false);
            AddBookToInventory("Fantastic Beasts and Where to Find Them", "Newt Scamander", 42.00m, true);
            AddBookToInventory("The Standard Book of Spells", "Miranda Goshawk", 25.00m, false);
        }

        private static void AddDemoCustomer()
        {
            Customers.Add(new Customer("Walk-in Wizard"));
        }

        private static void AddBookToInventory(string title, string author, decimal price, bool isMagical)
        {
            Books.Add(new Book(nextBookId++, title, author, price, isMagical));
        }

        private static MainMenuOption ReadMainMenuOption()
        {
            Console.WriteLine("1. Enter a new customer");
            Console.WriteLine("2. Add a new book");
            Console.WriteLine("3. Start a rental");
            Console.WriteLine("4. View customers");
            Console.WriteLine("5. View books");
            Console.WriteLine("0. Exit");
            return (MainMenuOption)ReadInteger("Choose an option: ", 0, 5);
        }

        private static void AddCustomer()
        {
            PrintHeading("ADD CUSTOMER");
            string name = ReadText("Enter the customer's name: ");
            Customers.Add(new Customer(name));
            Console.WriteLine($"Customer '{name}' was added successfully.");
        }

        private static void AddBook()
        {
            PrintHeading("ADD BOOK");
            string title = ReadText("Enter the book title: ");
            string author = ReadText("Enter the author's name: ");
            decimal price = ReadDecimal("Enter the rental price: ", 0.01m);
            bool magical = ReadYesNo("Is this a magical book? (y/n): ");

            AddBookToInventory(title, author, price, magical);
            Console.WriteLine("The book was added to the inventory.");
        }

        private static void StartRental()
        {
            if (Customers.Count == 0 || Books.Count == 0)
            {
                Console.WriteLine("A customer and at least one book are needed before a rental can start.");
                return;
            }

            PrintHeading("START RENTAL");
            Customer customer = ChooseCustomer();
            List<RentalLine> cart = new List<RentalLine>();
            bool continueShopping = true;

            while (continueShopping)
            {
                DisplayBooks();
                int bookId = ReadInteger("Enter a book ID to rent: ", 1, int.MaxValue);
                Book selectedBook = Books.FirstOrDefault(book => book.Id == bookId);

                if (selectedBook == null)
                {
                    Console.WriteLine("That book ID was not found.");
                    continue;
                }

                cart.Add(new RentalLine(selectedBook));
                Console.WriteLine($"'{selectedBook.Title}' was added to the cart.");
                RentalMenuOption nextAction = ReadRentalMenuOption();

                if (nextAction == RentalMenuOption.Checkout)
                {
                    Checkout(customer, cart);
                    continueShopping = false;
                }
                else if (nextAction == RentalMenuOption.CancelRental)
                {
                    cart.Clear();
                    Console.WriteLine("The rental was cancelled and the cart was reset.");
                    continueShopping = false;
                }
            }
        }

        private static RentalMenuOption ReadRentalMenuOption()
        {
            Console.WriteLine("\n1. Add another book");
            Console.WriteLine("0. Checkout");
            Console.WriteLine("2. Cancel rental");
            return (RentalMenuOption)ReadInteger("Choose an option: ", 0, 2);
        }

        private static Customer ChooseCustomer()
        {
            DisplayCustomers();
            int customerNumber = ReadInteger("Choose a customer number: ", 1, Customers.Count);
            return Customers[customerNumber - 1];
        }

        private static void Checkout(Customer customer, List<RentalLine> cart)
        {
            // All calculations are kept in one method so the checkout rules are easy to follow.
            decimal subtotal = cart.Sum(line => line.Book.RentalPrice);
            decimal timeDiscount = CalculateTimeDiscount(subtotal, DateTime.Now);
            int totalRentalsAfterCheckout = customer.TotalRentals + cart.Count;
            decimal couponDiscount = CalculateCouponDiscount(subtotal, totalRentalsAfterCheckout);
            decimal totalDiscount = timeDiscount + couponDiscount;
            decimal totalDue = Math.Max(0m, subtotal - totalDiscount);

            PrintHeading("CHECKOUT");
            Console.WriteLine($"Customer: {customer.Name}");
            Console.WriteLine("Books rented:");
            foreach (RentalLine line in cart)
            {
                Console.WriteLine($"- {line.Book.Title} ({line.Book.RentalPrice.ToString("C", CultureInfo.CurrentCulture)})");
            }

            Console.WriteLine($"\nSubtotal: {subtotal.ToString("C", CultureInfo.CurrentCulture)}");
            Console.WriteLine($"Time-based discount: -{timeDiscount.ToString("C", CultureInfo.CurrentCulture)}");
            Console.WriteLine($"Rental coupon discount: -{couponDiscount.ToString("C", CultureInfo.CurrentCulture)}");
            Console.WriteLine($"TOTAL DUE: {totalDue.ToString("C", CultureInfo.CurrentCulture)}");
            Console.WriteLine($"Coupons earned: {CalculateCouponsEarned(totalRentalsAfterCheckout)}");
            DisplayMagicalBonus(cart);

            customer.TotalRentals = totalRentalsAfterCheckout;
            customer.LifetimeSpend += totalDue;

            // Clearing the same cart object proves that the cart resets after checkout.
            cart.Clear();
            Console.WriteLine("\nCheckout complete. The cart has been reset for the next customer.");
        }

        private static decimal CalculateTimeDiscount(decimal subtotal, DateTime currentTime)
        {
            // The shop's evening spell gives 10% off for rentals made from 18:00 onwards.
            if (currentTime.Hour >= 18)
            {
                return subtotal * 0.10m;
            }

            return 0m;
        }

        private static decimal CalculateCouponDiscount(decimal subtotal, int rentalCount)
        {
            // Every third rental activates a 5% loyalty coupon on this checkout.
            if (rentalCount > 0 && rentalCount % 3 == 0)
            {
                return subtotal * 0.05m;
            }

            return 0m;
        }

        private static string CalculateCouponsEarned(int rentalCount)
        {
            int coupons = rentalCount / 3;
            return coupons == 0 ? "None yet" : $"{coupons} loyalty coupon(s) available";
        }

        private static void DisplayMagicalBonus(List<RentalLine> cart)
        {
            int magicalBooks = cart.Count(line => line.Book.IsMagical);
            if (magicalBooks >= 2)
            {
                Console.WriteLine("Room of Requirement bonus: 'The Tales of Beedle the Bard' was awarded.");
            }
            else if (magicalBooks == 1)
            {
                Console.WriteLine("Room of Requirement bonus: A silver bookmark was awarded.");
            }
            else
            {
                Console.WriteLine("Room of Requirement bonus: No magical bonus this time.");
            }
        }

        private static void DisplayCustomers()
        {
            PrintHeading("CUSTOMERS");
            for (int index = 0; index < Customers.Count; index++)
            {
                Customer customer = Customers[index];
                Console.WriteLine($"{index + 1}. {customer.Name} | Rentals: {customer.TotalRentals} | Spent: {customer.LifetimeSpend.ToString("C", CultureInfo.CurrentCulture)}");
            }
        }

        private static void DisplayBooks()
        {
            PrintHeading("BOOK INVENTORY");
            foreach (Book book in Books)
            {
                string type = book.IsMagical ? "Magical" : "Standard";
                Console.WriteLine($"ID {book.Id}: {book.Title} by {book.Author} | {book.RentalPrice.ToString("C", CultureInfo.CurrentCulture)} | {type}");
            }
        }

        private static string ReadText(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine()?.Trim() ?? string.Empty;
                if (!string.IsNullOrWhiteSpace(input))
                {
                    return input;
                }

                Console.WriteLine("Please enter a value.");
            }
        }

        private static int ReadInteger(string prompt, int minimum, int maximum)
        {
            while (true)
            {
                Console.Write(prompt);
                if (int.TryParse(Console.ReadLine(), out int number) && number >= minimum && number <= maximum)
                {
                    return number;
                }

                Console.WriteLine("Please enter a valid number from the displayed range.");
            }
        }

        private static decimal ReadDecimal(string prompt, decimal minimum)
        {
            while (true)
            {
                Console.Write(prompt);
                if (decimal.TryParse(Console.ReadLine(), NumberStyles.Number, CultureInfo.CurrentCulture, out decimal number) && number >= minimum)
                {
                    return number;
                }

                Console.WriteLine($"Please enter an amount of at least {minimum.ToString("C", CultureInfo.CurrentCulture)}.");
            }
        }

        private static bool ReadYesNo(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string answer = (Console.ReadLine() ?? string.Empty).Trim().ToLowerInvariant();
                if (answer == "y" || answer == "yes") return true;
                if (answer == "n" || answer == "no") return false;
                Console.WriteLine("Please answer y or n.");
            }
        }

        private static void PrintHeading(string heading)
        {
            Console.WriteLine("\n==================================================");
            Console.WriteLine(heading);
            Console.WriteLine("==================================================");
        }

        private static void Pause()
        {
            Console.WriteLine("\nPress ENTER to return to the main menu.");
            Console.ReadLine();
        }
    }
}

// References used during implementation:
// [1] Microsoft Learn, “Enumeration types - C# reference,”
//     https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/enum
// [2] Microsoft Learn, “List<T> Class,”
//     https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.list-1?view=net-10.0
// [3] Microsoft Learn, “Date, time, and time zones,”
//     https://learn.microsoft.com/en-us/dotnet/standard/datetime/

// Note: Replace the placeholder group members above before submitting. Read the whole program
// because the project defense can test every part of the solution.

// The code is intentionally written with simple classes, lists, enums, methods, and loops so it
// remains understandable to a beginner while still meeting the milestone requirements.

// End of Program.cs

// This final comment is intentionally plain: the implementation should be edited by the group
// so that the final submission reflects the group's own understanding and contribution.

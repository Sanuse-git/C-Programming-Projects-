# Pseudocode and Flow Description

## Main algorithm

1. Start the application.
2. Load a few sample books and one demonstration customer.
3. Display the enum-based main menu.
4. Read the user's menu choice.
5. If the user chooses **Add Customer**, ask for a name and store a new customer.
6. If the user chooses **Add Book**, ask for title, author, price, and magical status, then store the book.
7. If the user chooses **Start Rental**, select a customer and create an empty cart.
8. Display the available books.
9. Add the selected book to the cart.
10. Ask whether the user wants to add another book, checkout, or cancel.
11. If the user chooses to add another book, repeat the book-selection step.
12. If the user chooses checkout:
    - Calculate the subtotal.
    - Apply the evening time discount when the current hour is 18:00 or later.
    - Calculate the loyalty coupon discount when the customer's rental total reaches a multiple of three.
    - Display the rented books, subtotal, discounts, total due, coupons, and magical bonus.
    - Update the customer's rental count and lifetime spending.
    - Clear the cart.
13. If the user chooses cancel, clear the cart without updating the customer.
14. Return to the main menu.
15. If the user chooses exit, close the application.

## Simple flowchart

```mermaid
flowchart TD
    A([Start]) --> B[Load sample books and customer]
    B --> C{Main enum menu}
    C -->|Add customer| D[Read name and save customer]
    C -->|Add book| E[Read book details and save book]
    C -->|Start rental| F[Choose customer and create empty cart]
    F --> G[Choose a book and add it to cart]
    G --> H{Rental menu}
    H -->|Add another| G
    H -->|Checkout| I[Calculate subtotal and discounts]
    I --> J[Display receipt, coupons, and magical bonus]
    J --> K[Update customer and clear cart]
    H -->|Cancel| L[Clear cart]
    D --> C
    E --> C
    K --> C
    L --> C
    C -->|View customers/books| C
    C -->|Exit| M([End])
```

The flowchart shows the two important loops: the main menu loop allows multiple customers, and the rental loop allows multiple books in one cart.

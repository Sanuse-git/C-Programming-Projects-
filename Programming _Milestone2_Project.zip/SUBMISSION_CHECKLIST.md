# Final submission checklist

1. Replace the group-member placeholders in `Program.cs` and `README.md`.
2. Replace the contribution descriptions with what each person actually did.
3. Read and run the full application before the defense.
4. Confirm that the rules match the group's Milestone 1 proposal if the lecturer expects exact thresholds.
5. Run `dotnet build` and then `dotnet run`.
6. Submit the entire project folder as a ZIP file, as required by the brief.
7. Do not claim contributions that were not made. Each group member should be able to explain the complete program.

# Shared Student Budget Tracker

A C# console application for tracking a shared student household budget. The existing program supports a monthly budget, expenses in five categories, income, remaining-budget display, a category summary, and text-file persistence.

## Open and run

This repository retains the original **.NET Framework 4.7.2** project format. Open `SharedStudentBudgetTracker.slnx` in a compatible version of Visual Studio on Windows, then build and run the project. The console app reads and writes `BudgetTracker.txt` in its current working directory.

## Repository contents

- `Program.cs` — the supplied application source.
- `SharedStudentBudgetTracker.csproj` — renamed project file.
- `SharedStudentBudgetTracker.slnx` — renamed solution file.
- `App.config` and `Properties/AssemblyInfo.cs` — original framework/runtime metadata with updated product naming.
- `CODE_REVIEW.md` — review findings and a manual test checklist.

## Important

The source logic is retained from the uploaded project; it has **not** been rewritten or represented as tested. See `CODE_REVIEW.md` for correctness issues to investigate before relying on the program. The course brief says generative AI must not generate or submit assessed work, so use those notes as a study aid and make, test, and explain your own code changes.

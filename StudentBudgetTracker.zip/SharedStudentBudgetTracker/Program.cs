using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Budget_Tracker_182
{
    public class Program
    {
        //Used to save to the text file if the user closes the program by pressing the x button
        [DllImport("Kernel32")]
        private static extern bool SetConsoleCtrlHandler(ConsoleCtrlDelegate handler, bool add);
        private delegate bool ConsoleCtrlDelegate(int ctrlType);
        private static ConsoleCtrlDelegate _handler;
        //Stops here

        public static List<string> temp = new List<string>();
        public static List<string> lines = new List<string>();
        public static double[][] arrTransactions = new double[7][];
        public static string[] arrCategories;
        public static string filePath = "BudgetTracker.txt";
        public static int index;

        enum MainMenu //makes the ordered list for the menu
        {
            CreateBudget = 1,
            AddExpense,
            AddIncome,
            ViewBudget,
            ShowSummary,
            Exit,
        }

        enum ExpenseCategory //makes the ordered list for the expenses
        {
            Leisure = 1,
            Utilities,
            Food,
            Transport,
            Other,
            Back
        }

        static async Task Main() //The string args is for cli so I just remove it since we don't use them
        {
            //Used to save to the text file if the user closes the program by pressing the x button
            _handler = new ConsoleCtrlDelegate(ConsoleHandler);
            SetConsoleCtrlHandler(_handler, true);
            //Stops here

            double leisureTotal = 0, utilitiesTotal = 0, foodTotal = 0, transportTotal = 0, otherTotal = 0, incomeTotal = 0,
                   budget = 0;
            bool running = true;

            //Checking to see if the file exists and creates one if one is not found
            if (!File.Exists(filePath))
            {
                File.WriteAllText(filePath, "Budget\\\nLeisure\\\nUtilities\\\nFood\\\nTransport\\\nOther\\\nIncome\\");
            }

            lines = File.ReadAllLines(filePath).ToList();

            //Determines if there is already a previous budget stored in
            //the program and asks the user for one if none is found.
            if (lines[0] == "Budget\\")
            {
                Console.WriteLine("Please create your budget ex 100.00");
                budget = double.Parse(Console.ReadLine());
                lines[0] = lines[0] + budget + "\\";
                index = 1;
                Console.WriteLine("Thank you please press any key to go to the main menu");
                Console.ReadKey();
            }
            else { index = 0; }

            SaveToArrays();

            bool repeat; // feel free to move this up this is just here for basic validation since declaring this for each one felt excessive
            while (running)
            {
            Menu:
                Console.Clear();// Clears the console to keep it nice and clean
                Console.WriteLine("Welcome to Budget tracker 182 Please select one of the options below using it's corresponding number");
                Console.WriteLine("1 Create new budget");
                Console.WriteLine("2 Add expenses");
                Console.WriteLine("3 Add income");
                Console.WriteLine("4 View reamaining budget");
                Console.WriteLine("5 Show budget summary");
                Console.WriteLine("6 Exit");

                if (Enum.TryParse(Console.ReadLine(), true, out MainMenu menuOptions))
                {// Used to catch user input and direct them to selected option but also validates their input
                    Console.Clear();
                    switch (menuOptions)
                    {
                        case MainMenu.CreateBudget:
                            File.WriteAllText(filePath, "Budget\\\nLeisure\\\nUtilities\\\nFood\\\nTransport\\\nOther\\\nIncome\\");//Resets file for the new budget
                            lines = File.ReadAllLines(filePath).ToList();
                            if (lines[0] == "Budget\\")
                            {
                                repeat = true;
                                while (repeat)
                                {
                                    index = 1;
                                    Console.WriteLine("Please create your budget ex 100.00");
                                    if (double.TryParse(Console.ReadLine(), out double newBudget)) // Value is converted to double and if successful is stored in 'newBudget'
                                    {
                                        // Prevents negative values
                                        if (newBudget >= 0)
                                        {
                                            lines[0] = lines[0] + newBudget + "\\";// Updated the budget
                                            SaveToArrays();
                                            Console.WriteLine("Budget added successfully.");
                                            break;// in other instances like this, goto is used, should we change this to keep consistency?
                                        }
                                        else
                                        {
                                            DisplayError();
                                            Console.WriteLine("Budget cannot be negative.");
                                        }
                                    }
                                    else
                                    {
                                        repeat = ContinueError();
                                    }
                                }
                            }
                            else { index = 0; }
                            Continue();

                            break;

                        case MainMenu.AddExpense:
                        ExpenseCategory:
                            Console.Clear();
                            Console.WriteLine("Please chose in which category your expense belongs(if you type 6 you will go back to the menu)");
                            Console.WriteLine("1 leisure");
                            Console.WriteLine("2 Utilities");
                            Console.WriteLine("3 Food");
                            Console.WriteLine("4 transport");
                            Console.WriteLine("5 Other");

                            if (Enum.TryParse(Console.ReadLine(), true, out ExpenseCategory Category)) ;
                            Console.Clear();
                            switch (Category)
                            {
                                case ExpenseCategory.Leisure:
                                    repeat = true;
                                    while (repeat)
                                    {
                                        Console.WriteLine("Please enter the amount of the expense ex 50.00");
                                        if (double.TryParse(Console.ReadLine(), out double leisure)) // Value is converted to double and if successful is stored in 'newBudget'
                                        {
                                            // Prevents negative values
                                            if (leisure >= 0)
                                            {
                                                if (AddToTransactions(1, leisure))
                                                {
                                                    Console.WriteLine("You will exceed the budget with this expense. Please rethink your purchase");
                                                    Continue();
                                                    goto Menu;
                                                }
                                                Console.WriteLine("Expense added successfully.");
                                                break;
                                            }
                                            else
                                            {
                                                DisplayError();
                                                Console.WriteLine("Amount cannot be negative.");
                                            }
                                        }
                                        else
                                        {
                                            repeat = ContinueError();
                                        }
                                    }
                                    goto Menu;

                                case ExpenseCategory.Utilities:
                                    repeat = true;
                                    while (repeat)
                                    {
                                        Console.WriteLine("Please enter the amount of the expense ex 50.00");
                                        if (double.TryParse(Console.ReadLine(), out double utilities)) // Value is converted to double and if successful is stored in 'newBudget'
                                        {
                                            // Prevents negative values
                                            if (utilities >= 0)
                                            {
                                                if (AddToTransactions(2, utilities))
                                                {
                                                    Console.WriteLine("You will exceed the budget with this expense. Please rethink your purchase");
                                                    Continue();
                                                    goto Menu;
                                                }
                                                Console.WriteLine("Expense added successfully.");
                                                break;
                                            }
                                            else
                                            {
                                                DisplayError();
                                                Console.WriteLine("Amount cannot be negative.");
                                            }
                                        }
                                        else
                                        {
                                            repeat = ContinueError();
                                        }
                                    }
                                    goto Menu;

                                case ExpenseCategory.Food:
                                    repeat = true;
                                    while (repeat)
                                    {
                                        Console.WriteLine("Please enter the amount of the expense ex 50.00");
                                        if (double.TryParse(Console.ReadLine(), out double food)) // Value is converted to double and if successful is stored in 'newBudget'
                                        {
                                            // Prevents negative values
                                            if (food >= 0)
                                            {
                                                if (AddToTransactions(3, food))
                                                {
                                                    Console.WriteLine("You will exceed the budget with this expense. Please rethink your purchase");
                                                    Continue();
                                                    goto Menu;
                                                }
                                                Console.WriteLine("Expense added successfully.");
                                                break;
                                            }
                                            else
                                            {
                                                DisplayError();
                                                Console.WriteLine("Amount cannot be negative.");
                                            }
                                        }
                                        else
                                        {
                                            repeat = ContinueError();
                                        }
                                    }
                                    goto Menu;

                                case ExpenseCategory.Transport:
                                    repeat = true;
                                    while (repeat)
                                    {
                                        Console.WriteLine("Please enter the amount of the expense ex 50.00");
                                        if (double.TryParse(Console.ReadLine(), out double transport)) // Value is converted to double and if successful is stored in 'newBudget'
                                        {
                                            // Prevents negative values
                                            if (transport >= 0)
                                            {
                                                if (AddToTransactions(4, transport))
                                                {
                                                    Console.WriteLine("You will exceed the budget with this expense. Please rethink your purchase");
                                                    Continue();
                                                    goto Menu;
                                                }
                                                Console.WriteLine("Expense added successfully.");
                                                break;
                                            }
                                            else
                                            {
                                                DisplayError();
                                                Console.WriteLine("Amount cannot be negative.");
                                            }
                                        }
                                        else
                                        {
                                            repeat = ContinueError();
                                        }
                                    }
                                    goto Menu;

                                case ExpenseCategory.Other:
                                    repeat = true;
                                    while (repeat)
                                    {
                                        Console.WriteLine("Please enter the amount of the expense ex 50.00");
                                        if (double.TryParse(Console.ReadLine(), out double other)) // Value is converted to double and if successful is stored in 'newBudget'
                                        {
                                            // Prevents negative values
                                            if (other >= 0)
                                            {
                                                if (AddToTransactions(5, other))
                                                {
                                                    Console.WriteLine("You will exceed the budget with this expense. Please rethink your purchase");
                                                    Continue();
                                                    goto Menu;
                                                }
                                                Console.WriteLine("Expense added successfully.");
                                                break;
                                            }
                                            else
                                            {
                                                DisplayError();
                                                Console.Write("Amount cannot be negative.");
                                            }
                                        }
                                        else
                                        {
                                            repeat = ContinueError();
                                        }
                                    }
                                    goto Menu;
                                case ExpenseCategory.Back:
                                    goto Menu;
                                default:
                                    DisplayError();
                                    Console.WriteLine("Please enter a numerical value from the given selection");
                                    Continue();
                                    goto ExpenseCategory;
                            }

                        case MainMenu.AddIncome:
                            repeat = true;
                            while (repeat)
                            {
                                Console.WriteLine("Please add an income ex 100.00");
                                if (double.TryParse(Console.ReadLine(), out double income))
                                {
                                    if (income >= 0)
                                    {
                                        //adds the income to the jagged array and to the budget
                                        Array.Resize(ref arrTransactions[6], arrTransactions[6].Length + 1);
                                        arrTransactions[6][arrTransactions[6].Length - 1] = income;
                                        Array.Resize(ref arrTransactions[0], arrTransactions[0].Length + 1);
                                        arrTransactions[0][arrTransactions[0].Length - 1] = arrTransactions[0][arrTransactions[0].Length - 2] + income;
                                        Console.WriteLine("Income added successfully.");
                                        Continue();
                                        goto Menu;
                                    }
                                    else
                                    {
                                        DisplayError();
                                        Console.WriteLine("Income cannot be negative.");
                                    }
                                }
                                else
                                {
                                    repeat = ContinueError();
                                }
                            }
                            break;

                        case MainMenu.ViewBudget:
                            Console.WriteLine($"Your remaining budget is {arrTransactions[0][arrTransactions[0].Length - 1]}");//Displays remaining budget
                            Continue();
                            break;

                        case MainMenu.ShowSummary:
                            //Calculates the totals for each categorie
                            for (int i = 1; i < 7; i++)
                            {
                                switch (i)
                                {
                                    case 1:
                                        leisureTotal = 0;
                                        foreach (double amount in arrTransactions[i])
                                        {
                                            leisureTotal = leisureTotal + amount; //do we change these to += ?
                                        }
                                        break;
                                    case 2:
                                        utilitiesTotal = 0;
                                        foreach (double amount in arrTransactions[i])
                                        {
                                            utilitiesTotal = utilitiesTotal + amount;
                                        }
                                        break;
                                    case 3:
                                        foodTotal = 0;
                                        foreach (double amount in arrTransactions[i])
                                        {
                                            foodTotal = foodTotal + amount;
                                        }
                                        break;
                                    case 4:
                                        transportTotal = 0;
                                        foreach (double amount in arrTransactions[i])
                                        {
                                            transportTotal = transportTotal + amount;
                                        }
                                        break;
                                    case 5:
                                        otherTotal = 0;
                                        foreach (double amount in arrTransactions[i])
                                        {
                                            otherTotal = otherTotal + amount;
                                        }
                                        break;
                                    case 6:
                                        incomeTotal = 0;
                                        foreach (double amount in arrTransactions[i])
                                        {
                                            incomeTotal = incomeTotal + amount;
                                        }
                                        break;
                                }
                            }

                            //Declaring dictionary with all the category totals
                            Dictionary<string, double> categoryTotals = new Dictionary<string, double>()
                            {
                                { "Leisure",leisureTotal},
                                { "Utilities",utilitiesTotal},
                                { "Food",foodTotal},
                                { "Transport",transportTotal},
                                { "Other",otherTotal}
                            };

                            var largestTotal = categoryTotals.OrderByDescending(x => x.Value).FirstOrDefault();

                            Console.WriteLine("Here is your summary");

                            Console.WriteLine("---------Expenses---------");
                            foreach (var category in categoryTotals)//Displays all totals
                            {
                                Console.WriteLine("{0}: {1}", category.Key, category.Value.ToString("C", CultureInfo.CreateSpecificCulture("en-ZA")));
                            }
                            Console.WriteLine("--------------------------");
                            Console.WriteLine($"You have spent a total of {(leisureTotal + utilitiesTotal + foodTotal + transportTotal + otherTotal).ToString("C", CultureInfo.CreateSpecificCulture("en-ZA"))}");
                            Console.WriteLine($"Your total income is {incomeTotal.ToString("C", CultureInfo.CreateSpecificCulture("en-ZA"))}");
                            Console.WriteLine($"Highest expense category: {largestTotal.Key} ({largestTotal.Value.ToString("C", CultureInfo.CreateSpecificCulture("en-ZA"))})");

                            if (largestTotal.Key == "Leisure")// checks to see if Leisure was the category with the most expenses
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Warning: ");
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine("Your highest expense was Leisure.Funds have not properly been used.");
                                Continue();
                                goto Menu;
                            }
                            Continue();
                            break;

                        case MainMenu.Exit:
                            running = false;
                            SaveToFile();
                            Console.WriteLine("Thank you for using budget tracker 182 have a nice day press any button to exit");
                            Console.ReadKey();
                            break;
                        default:
                            Console.WriteLine("Selected valid menu option");
                            Continue();
                            break;
                    }
                }
                else
                {
                    DisplayError();
                    Console.WriteLine("UnuseableInput\nInput must be a number, press any key to try again");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
        }
        //Used to add a value to the jagged array transactions and to validate the users input
        public static bool AddToTransactions(int x, double expense)
        {
            if (arrTransactions[0][arrTransactions[0].Length - 1] < expense)
            {
                return true;
            }
            else
            {
                Array.Resize(ref arrTransactions[x], arrTransactions[x].Length + 1);
                arrTransactions[x][arrTransactions[x].Length - 1] = expense;
                Array.Resize(ref arrTransactions[0], arrTransactions[0].Length + 1);
                arrTransactions[0][arrTransactions[0].Length - 1] = arrTransactions[0][arrTransactions[0].Length - 2] - expense;
                return false;
            }
        }
        public static void Continue()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Thank you please press any key to return to the main menu");
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
        }
        public static bool ContinueError()
        {
            bool repeat = true;
            Console.Clear();
            Console.WriteLine("Failed to read input, would you like to try again?\ny/n :");
            string tempstring = Console.ReadLine();
            if (tempstring.ToLower() == "n")
            {
                repeat = false;
            }
            else if (tempstring.ToLower() != "y")
            {
                Console.WriteLine($"\"{tempstring}\" is not a valid option, returning to menu");
                Console.ReadKey(true);
                repeat = false;
            } else if (tempstring.ToLower() == "y")
            {
                Console.Clear();
                repeat = true;
            }

            return repeat;
        }
        //Used to save changes to the text file
        public static void SaveToFile()
        {
            lines.Clear();
            for (int i = 0; i < 7; i++)
            {
                lines.Add(arrCategories[i] + "\\");
                foreach (double value in arrTransactions[i])
                {
                    lines[i] = lines[i] + value + "\\";
                }
            }
            File.WriteAllLines(filePath, lines);
        }
        //Used to save to the text file if the user closes the program by pressing the x button
        private static bool ConsoleHandler(int ctrlType)
        {
            // ctrlType 2 corresponds to CTRL_CLOSE_EVENT (X button clicked)
            if (ctrlType == 2)
            {
                SaveToFile();
                return true;
            }
            return false;
        }

        //Saves the text file values to the arrays
        public static void SaveToArrays()
        {
            string line;
            temp = File.ReadAllLines(filePath).ToList();

            for (int i = 0; i < temp.Count; i++)
            {
                int counter = index;
                while (temp[i].Contains(@"\"))
                {
                    temp[i] = temp[i].Remove(temp[i].IndexOf(@"\"), 1);
                    counter++;
                }
                arrTransactions[i] = new double[counter - 1];
            }

            arrCategories = new string[lines.Count];

            //Populating categories array
            for (int i = 0; i < lines.Count; i++)
            {
                line = lines[i].Substring(0, lines[i].IndexOf(@"\"));
                lines[i] = lines[i].Remove(0, 1 + lines[i].IndexOf(@"\"));
                arrCategories[i] = line;
            }

            //Populating transactions jagged array
            for (int i = 0; i < 7; i++)
            {
                int counter = 0;
                while (lines[i].Contains(@"\"))
                {
                    arrTransactions[i][counter] = double.Parse(lines[i].Substring(0, lines[i].IndexOf(@"\")));
                    lines[i] = lines[i].Remove(0, 1 + lines[i].IndexOf(@"\"));
                    counter++;
                }
            }
        }
        //Displays error in red font
        public static void DisplayError()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Error: ");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}

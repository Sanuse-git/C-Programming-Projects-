# Code review: Shared Student Budget Tracker

This review is based on the supplied `Program.cs`. It is a learning aid, not a replacement implementation. The source is retained as provided so you can decide, make, test, and explain your own changes.

## Highest-priority findings

1. **Fresh setup can fail while loading the first budget.** In `Main`, the initial amount is appended to the in-memory `lines` list, but `SaveToArrays()` sizes arrays using `File.ReadAllLines(filePath)` and then populates them from `lines`. Those two representations can disagree when the file still contains only the default category headings. Investigate making startup and “Create new budget” use one consistent persistence/loading sequence. Test from a directory where `BudgetTracker.txt` does not exist.
2. **Invalid startup budget input can terminate the program.** The first-run path uses `double.Parse` rather than the validation loop used elsewhere. Apply the same input validation there, including blank, non-numeric, negative, and very large values.
3. **The shutdown hook is Windows-specific.** `SetConsoleCtrlHandler` imports `Kernel32`, so the app is tied to Windows. It only saves on one close event and does not replace saving after each successful operation. Decide whether to keep a Windows-only target or remove the platform dependency; make persistence reliable independently of closing the console window.
4. **Persistence parsing is brittle.** The text format uses backslash delimiters and assumes a fixed number/order of lines and valid numeric values. A truncated or edited file can cause `IndexOutOfRangeException`, `FormatException`, or substring errors. Add file-shape/value validation and a recoverable error path; consider a clearly documented, versionable format.
5. **Money is stored as `double`.** Binary floating-point is not ideal for currency totals. Review using `decimal` and consistent currency formatting/parsing with an explicit culture.

## Other improvement opportunities

- The expense-category menu repeats near-identical input/validation blocks. Consider one shared method that receives the chosen category and amount; this reduces copy/paste errors.
- The category prompt uses `if (Enum.TryParse(...));` with a stray empty statement, so the parse result is ignored. Handle the result explicitly and report invalid choices before the `switch`.
- Add-income and add-expense paths update the balance array directly. Encapsulate updates so each accepted transaction changes the ledger and balance together, and rejected transactions change neither.
- The summary chooses a highest category even when all categories are zero, and the “Leisure” warning assumes that the largest leisure total means funds were misused. Consider a neutral message and an explicit no-expenses case.
- Menu wording and formatting can be made consistent (for example, “remaining” and “choose”). Show amounts using the same South African currency format throughout.
- Save after successful changes, or clearly communicate that changes are only persisted when exiting normally.

## Manual test checklist

1. Start with no data file; create a valid budget; exit and restart; confirm the balance is preserved.
2. At first-run budget input, try blank text, letters, a negative number, zero, and a valid decimal amount.
3. Add one expense in each category; view the remaining budget and summary; confirm category totals and the overall total.
4. Try an expense equal to the balance, one larger than the balance, zero, a negative number, and non-numeric text.
5. Add income after expenses; confirm income total and remaining balance both update correctly.
6. Choose invalid menu/category values (including out-of-range numbers and text); confirm the program remains usable.
7. Close and restart after adding records; verify expected persistence. Also test a missing, empty, truncated, and malformed data file.
8. Run under the intended Windows/.NET Framework environment; if cross-platform support is intended, verify the close behavior on each target platform.

## Rename and packaging changes in this copy

The project/solution filenames, assembly name, and assembly title/product name were changed to `SharedStudentBudgetTracker`. IDE caches, build outputs, and the uploaded repository's embedded `.git` directory were excluded. The application logic in `Program.cs` was not changed in this copy.

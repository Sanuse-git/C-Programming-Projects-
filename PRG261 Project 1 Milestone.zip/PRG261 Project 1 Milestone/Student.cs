﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG261_Project_1_Milestone
{
    public class Student
    {
        public string FullName { get; set; }
        public string StudentNumber { get; set; }
        public int YearOfStudy { get; set; }
        public string EquipmentType { get; set; }
        public int BookingDuration { get; set; }
        public bool HasTraining { get; set; }
        public int ActiveBookings { get; set; }
        public string Status { get; set; } // Approved, Rejected, or Conditionally Approved

    }
}

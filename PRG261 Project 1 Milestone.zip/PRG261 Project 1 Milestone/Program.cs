﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG261_Project_1_Milestone
{
    enum Menu
    {
        Capture = 1,
        Evaluate,
        Statistics,
        Exit
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            BookingManager manager = new BookingManager();
            List<Student> allRequests = new List<Student>();
            List<Student> approvedRequests = new List<Student>();
            int rejectedCount = 0;
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n--- TechnoLab Management System ---");
                Console.WriteLine("1. Capture Booking Requests");
                Console.WriteLine("2. Evaluate Booking Eligibility");
                Console.WriteLine("3. Display Booking Statistics");
                Console.WriteLine("4. Exit");
                Console.Write("Select an option: ");

                if (Enum.TryParse(Console.ReadLine(), out Menu userChoice))
                {
                    switch (userChoice)
                    {
                        case Menu.Capture:
                            allRequests = manager.CaptureBookings();
                            break;
                        case Menu.Evaluate:
                            approvedRequests = manager.EvaluateBookings(allRequests, out rejectedCount);
                            break;
                        case Menu.Statistics:
                            manager.DisplayStatistics(allRequests, approvedRequests, rejectedCount);
                            break;
                        case Menu.Exit:
                            running = false;
                            Console.WriteLine("Exiting program...");
                            break;
                        default:
                            Console.WriteLine("Invalid selection.");
                            break;
                    }
                }
            }
        }
    }

}
      

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG261_Project_1_Milestone
{
    public class BookingManager
    {
        // Option 1: Capture Booking Requests
        public List<Student> CaptureBookings()
        {
            List<Student> students = new List<Student>();
            string choice;

            do
            {
                Student s = new Student();
                Console.WriteLine("\n--- Enter Booking Details ---");
                Console.Write("Full Name: ");
                s.FullName = Console.ReadLine();
                Console.Write("Student Number: ");
                s.StudentNumber = Console.ReadLine();
                Console.Write("Year of Study: ");
                s.YearOfStudy = int.Parse(Console.ReadLine());
                Console.Write("Equipment Type: ");
                s.EquipmentType = Console.ReadLine();
                Console.Write("Duration (hours): ");
                s.BookingDuration = int.Parse(Console.ReadLine());
                Console.Write("Completed Training? (yes/no): ");
                s.HasTraining = Console.ReadLine().ToLower() == "yes";
                Console.Write("Current Active Bookings: ");
                s.ActiveBookings = int.Parse(Console.ReadLine());

                students.Add(s);

                Console.Write("\nAdd another booking? (y/n): ");
                choice = Console.ReadLine().ToLower();
            } while (choice == "y");

            return students;
        }

        // Option 2: Evaluate Booking Eligibility
        public List<Student> EvaluateBookings(List<Student> allBookings, out int rejectedCount)
        {
            List<Student> approvedList = new List<Student>();
            rejectedCount = 0;

            foreach (var s in allBookings)
            {
                // Rejection Logic
                if (s.BookingDuration > 6 || s.ActiveBookings >= 3)
                {
                    s.Status = "Rejected";
                    rejectedCount++;
                }
                // Approval Logic
                else if (s.HasTraining && s.BookingDuration <= 4 && s.ActiveBookings < 2)
                {
                    s.Status = "Approved";
                    approvedList.Add(s);
                }
                // Conditional Approval Logic
                else if ((s.BookingDuration == 5 || s.BookingDuration == 6) && s.HasTraining && s.ActiveBookings < 2)
                {
                    s.Status = "Conditionally Approved";
                    approvedList.Add(s);
                }
                else
                {
                    s.Status = "Rejected";
                    rejectedCount++;
                }
            }
            Console.WriteLine("\nEvaluation Complete!");
            return approvedList;
        }

        // Option 3: Display Booking Statistics
        public void DisplayStatistics(List<Student> allBookings, List<Student> approvedBookings, int rejectedCount)
        {
            Console.WriteLine("\n--- Booking Statistics ---");
            Console.WriteLine($"Total Requests: {allBookings.Count}");
            Console.WriteLine($"Approved (incl. Conditional): {approvedBookings.Count}");
            Console.WriteLine($"Rejected: {rejectedCount}");

            // Sorting for priority: Year (asc), Active Bookings (asc), Duration (asc)
            var sortedList = approvedBookings
                .OrderBy(s => s.YearOfStudy)
                .ThenBy(s => s.ActiveBookings)
                .ThenBy(s => s.BookingDuration)
                .ToList();

            Console.WriteLine("\n--- Priority Approved Bookings ---");
            foreach (var s in sortedList)
            {
                Console.WriteLine($"[{s.Status}] {s.FullName} - Year: {s.YearOfStudy}, Duration: {s.BookingDuration}hrs");
            }
        }
    }
}

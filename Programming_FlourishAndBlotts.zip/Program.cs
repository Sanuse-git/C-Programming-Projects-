using System;
using System.Collections.Generic;

namespace FlourishAndBlotts;

// PRG161 Milestone 2
// Group members: Replace these placeholders with the real names before submission.
// Contributions: Member 1 - menu and input validation; Member 2 - rental/cart logic;
// Member 3 - checkout, discounts and rewards; Member 4 - testing and documentation.

public class Book
{
    public string Title { get; }
    public decimal RentalPrice { get; }

    public Book(string title, decimal rentalPrice)
    {
        Title = title;
        RentalPrice = rentalPrice;
    }
}

public class Customer
{
    public string Name { get; }
    public string PhoneNumber { get; }

    public Customer(string name, string phoneNumber)
    {
        Name = name;
        PhoneNumber = phoneNumber;
    }
}

// An enum gives every menu option a meaningful name instead of using unexplained numbers.
public enum MenuChoice
{
    EnterCustomer = 1,
    AddBook = 2,
    RentBooks = 3,
    Checkout = 4,
    Exit = 5
}

public static class Program
{
    private static readonly List<Book> Catalogue = new();
    private static readonly List<Book> Cart = new();
    private static Customer? currentCustomer;

    public static void Main()
    {
        SeedCatalogue();
        bool keepRunning = true;

        Console.WriteLine("==============================================");
        Console.WriteLine("      FLOURISH & BLOTTS MAGICAL CASH REGISTER");
        Console.WriteLine("==============================================");
        Console.WriteLine("Welcome! This register manages book rentals and loyalty rewards.\n");

        while (keepRunning)
        {
            ShowMenu();
            MenuChoice choice = ReadMenuChoice();
            Console.WriteLine();

            switch (choice)
            {
                case MenuChoice.EnterCustomer:
                    EnterCustomer();
                    break;
                case MenuChoice.AddBook:
                    AddBookToCatalogue();
                    break;
                case MenuChoice.RentBooks:
                    RentBooks();
                    break;
                case MenuChoice.Checkout:
                    Checkout();
                    break;
                case MenuChoice.Exit:
                    keepRunning = false;
                    Console.WriteLine("Thank you for visiting Flourish & Blotts. Goodbye!");
                    break;
            }

            if (keepRunning)
            {
                Console.WriteLine("\nPress ENTER to return to the menu.");
                Console.ReadLine();
                Console.Clear();
            }
        }
    }

    private static void SeedCatalogue()
    {
        // These sample books make the program usable immediately. More books can be added from the menu.
        Catalogue.Add(new Book("The Standard Book of Spells", 25.00m));
        Catalogue.Add(new Book("Fantastic Beasts and Where to Find Them", 35.00m));
        Catalogue.Add(new Book("The Monster Book of Monsters", 45.00m));
    }

    private static void ShowMenu()
    {
        Console.WriteLine("MAIN MENU");
        Console.WriteLine("1. Enter a new customer");
        Console.WriteLine("2. Add a new book to the catalogue");
        Console.WriteLine("3. Rent one or more books");
        Console.WriteLine("4. Check out current customer");
        Console.WriteLine("5. Exit");
    }

    private static MenuChoice ReadMenuChoice()
    {
        while (true)
        {
            Console.Write("Choose an option (1-5): ");
            string input = Console.ReadLine() ?? string.Empty;

            if (int.TryParse(input, out int number) && Enum.IsDefined(typeof(MenuChoice), number))
            {
                return (MenuChoice)number;
            }

            Console.WriteLine("That is not a valid menu option. Please enter a number from 1 to 5.");
        }
    }

    private static void EnterCustomer()
    {
        string name = ReadRequiredText("Customer name: ");
        string phone = ReadRequiredText("Customer phone number: ");
        currentCustomer = new Customer(name, phone);
        Cart.Clear();
        Console.WriteLine($"Customer '{currentCustomer.Name}' is ready. The rental cart has been cleared for this customer.");
    }

    private static void AddBookToCatalogue()
    {
        Console.WriteLine("ADD A BOOK");
        string title = ReadRequiredText("Book title: ");
        decimal price = ReadPositivePrice("Rental price: ");
        Catalogue.Add(new Book(title, price));
        Console.WriteLine($"'{title}' was added to the catalogue at {price:C2} per rental.");
    }

    private static void RentBooks()
    {
        if (currentCustomer is null)
        {
            Console.WriteLine("Please enter a customer before renting books.");
            return;
        }

        if (Catalogue.Count == 0)
        {
            Console.WriteLine("There are no books in the catalogue.");
            return;
        }

        bool addAnother = true;
        while (addAnother)
        {
            Console.WriteLine($"BOOK CATALOGUE for {currentCustomer.Name}");
            for (int i = 0; i < Catalogue.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Catalogue[i].Title} - {Catalogue[i].RentalPrice:C2}");
            }

            int bookNumber = ReadNumberInRange("Enter the book number to rent: ", 1, Catalogue.Count);
            Book selectedBook = Catalogue[bookNumber - 1];
            Cart.Add(selectedBook);
            Console.WriteLine($"Added '{selectedBook.Title}' to the cart.");
            Console.WriteLine($"Current cart total: {CalculateSubtotal(Cart):C2}");

            addAnother = ReadYesOrNo("Rent another book? (Y/N): ");
        }
    }

    private static void Checkout()
    {
        if (currentCustomer is null)
        {
            Console.WriteLine("Please enter a customer before checking out.");
            return;
        }

        if (Cart.Count == 0)
        {
            Console.WriteLine("The cart is empty. Rent at least one book before checking out.");
            return;
        }

        // Capture the time once so the whole receipt uses one consistent discount decision.
        DateTime checkoutTime = DateTime.Now;
        decimal subtotal = CalculateSubtotal(Cart);
        decimal discountRate = GetTimeDiscountRate(checkoutTime);
        decimal discountAmount = subtotal * discountRate;
        decimal totalDue = subtotal - discountAmount;
        int couponsEarned = CalculateCoupons(Cart.Count);
        List<string> magicalBooks = GetMagicalRewards(Cart.Count);

        Console.WriteLine("\n============== CHECKOUT RECEIPT ==============");
        Console.WriteLine($"Customer: {currentCustomer.Name}");
        Console.WriteLine($"Checkout time: {checkoutTime:yyyy-MM-dd HH:mm}");
        Console.WriteLine("\nRented books:");
        foreach (Book book in Cart)
        {
            Console.WriteLine($"- {book.Title} ({book.RentalPrice:C2})");
        }

        Console.WriteLine($"\nSubtotal: {subtotal:C2}");
        Console.WriteLine($"Time-based discount: {discountRate:P0} (-{discountAmount:C2})");
        Console.WriteLine($"TOTAL DUE: {totalDue:C2}");
        Console.WriteLine($"Coupons earned: {couponsEarned} (one future-use coupon per three rentals)");
        Console.WriteLine("Magical books from the Room of Requirement:");
        if (magicalBooks.Count == 0)
        {
            Console.WriteLine("- No magical bonus this time.");
        }
        else
        {
            foreach (string reward in magicalBooks)
            {
                Console.WriteLine($"- {reward}");
            }
        }
        Console.WriteLine("===============================================");

        // The receipt is printed first. Only then is the active cart reset for the next customer.
        Cart.Clear();
        currentCustomer = null;
        Console.WriteLine("Checkout complete. The cart has been reset for the next customer.");
    }

    private static decimal CalculateSubtotal(List<Book> books)
    {
        decimal subtotal = 0m;
        foreach (Book book in books)
        {
            subtotal += book.RentalPrice;
        }
        return subtotal;
    }

    private static decimal GetTimeDiscountRate(DateTime checkoutTime)
    {
        TimeSpan time = checkoutTime.TimeOfDay;

        // Project assumption: morning is 10%, afternoon is 5%, and other times are 0%.
        if (time >= new TimeSpan(9, 0, 0) && time < new TimeSpan(12, 0, 0))
        {
            return 0.10m;
        }

        if (time >= new TimeSpan(12, 0, 0) && time < new TimeSpan(17, 0, 0))
        {
            return 0.05m;
        }

        return 0m;
    }

    private static int CalculateCoupons(int rentalCount)
    {
        // Integer division awards one coupon for every complete group of three rentals.
        return rentalCount / 3;
    }

    private static List<string> GetMagicalRewards(int rentalCount)
    {
        List<string> rewards = new();

        // Project assumption: rewards are cumulative and are free gifts, not extra rentals.
        if (rentalCount >= 5)
        {
            rewards.Add("The Monster Book of Monsters");
        }

        if (rentalCount >= 8)
        {
            rewards.Add("Fantastic Beasts and Where to Find Them");
        }

        return rewards;
    }

    private static string ReadRequiredText(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string value = (Console.ReadLine() ?? string.Empty).Trim();
            if (value.Length > 0)
            {
                return value;
            }
            Console.WriteLine("This field may not be blank.");
        }
    }

    private static decimal ReadPositivePrice(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string input = Console.ReadLine() ?? string.Empty;
            if (decimal.TryParse(input, out decimal price) && price > 0)
            {
                return price;
            }
            Console.WriteLine("Please enter a price greater than zero, for example 25.00.");
        }
    }

    private static int ReadNumberInRange(string prompt, int minimum, int maximum)
    {
        while (true)
        {
            Console.Write(prompt);
            string input = Console.ReadLine() ?? string.Empty;
            if (int.TryParse(input, out int number) && number >= minimum && number <= maximum)
            {
                return number;
            }
            Console.WriteLine($"Please enter a whole number from {minimum} to {maximum}.");
        }
    }

    private static bool ReadYesOrNo(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string answer = (Console.ReadLine() ?? string.Empty).Trim().ToUpperInvariant();
            if (answer == "Y") return true;
            if (answer == "N") return false;
            Console.WriteLine("Please enter Y for yes or N for no.");
        }
    }
}

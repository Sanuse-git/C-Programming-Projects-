# Test Plan and Defense Notes

## Manual acceptance tests

Run these tests after replacing any project-specific rules supplied by the lecturer. Record the actual result beside each expected result.

| Test | Steps | Expected result |
|---|---|---|
| 1. Start and exit | Run the app and choose 5. | The welcome message appears and the program exits cleanly. |
| 2. Invalid menu input | Enter letters, 0, and 6 at the main menu. | The program rejects each input and asks again. |
| 3. Customer validation | Choose 1 and leave the name blank. | The program refuses blank input and asks again. |
| 4. Add-book validation | Choose 2; enter a blank title, then a negative price. | Both values are rejected. A valid title and price add one book. |
| 5. Rental without customer | Choose 3 before entering a customer. | The program explains that a customer is required. |
| 6. Multiple rentals | Enter a customer, choose 3, rent two different books, then choose N. | Both books appear in the cart and the subtotal equals their prices. |
| 7. Empty checkout | Enter a customer and choose 4 without renting. | Checkout is blocked and the cart is not changed. |
| 8. Three-rental coupon boundary | Rent exactly three books and check out. | The receipt shows one coupon. |
| 9. Below coupon boundary | Rent two books and check out. | The receipt shows zero coupons. |
| 10. Five-rental magical boundary | Rent five books and check out. | The receipt shows *The Monster Book of Monsters*. |
| 11. Eight-rental magical boundary | Rent eight books and check out. | The receipt shows both magical rewards. |
| 12. Discount check | Check out during the applicable time window. | The receipt shows the correct percentage and final total. |
| 13. Calculation check | Rent books priced at 25.00 and 35.00 during a 10% window. | Subtotal is 60.00, discount is 6.00, and total due is 54.00. |
| 14. Cart reset | Complete checkout for Customer A, then enter Customer B and rent one book. | Customer B sees only the new rental. |
| 15. Repeat loop | Complete two separate customers in one run. | The application returns to the menu after each checkout. |

## Five-minute defense route

First explain that the application is a console-based magical book-rental register. The `MenuChoice` enum makes the menu readable and the `switch` in `Main` sends each choice to a focused method. Then demonstrate entering a customer and renting multiple books.

Next show the checkout. Explain that `CalculateSubtotal` adds every `decimal` rental price. `GetTimeDiscountRate` reads the checkout time once and returns one percentage. The amount due is calculated as subtotal minus discount amount. `CalculateCoupons` uses integer division so three rentals produce one coupon. `GetMagicalRewards` returns free reward names based on rental-count thresholds.

Finish by pointing out that the receipt is displayed before `Cart.Clear()` runs. The current customer is then set to `null`, so the next customer starts with a clean cart. Mention that the numeric loyalty rules are documented assumptions because the brief did not give exact values.

## Likely lecturer questions

**Why did you use an enum?** An enum gives names to fixed menu choices and avoids unexplained numbers throughout the program.

**Why use `decimal` for prices?** `decimal` is designed for financial calculations and avoids using floating-point values for currency.

**Why use a `List<Book>`?** The cart can contain any number of rentals, and a list supports adding, counting, looping, and clearing those rentals.

**Why do you use `TryParse`?** Console input is text. `TryParse` checks whether the text can safely become a number without throwing an exception.

**Why capture `DateTime.Now` only once?** One checkout should use one consistent time. Calling it repeatedly could produce inconsistent results at a boundary.

**How does the cart reset?** After the receipt is printed, `Cart.Clear()` removes the active rentals and `currentCustomer = null` prepares the next transaction.

**What happens if the user tries to rent before entering a customer?** The method checks for a missing customer and returns without changing the cart.

**What are the project assumptions?** The brief requires discounts, coupons, and magical bonuses but does not specify their exact rates or thresholds. The assumptions are stated in the README and isolated in small methods so they can be changed.

**What did each group member contribute?** Replace the placeholders in `Program.cs` with the real allocation. Every member must still understand the entire program for the defense.

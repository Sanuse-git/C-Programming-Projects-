# PRG161 Milestone 2: Flourish & Blotts Magical Cash Register

## Project summary

This project is a beginner-friendly C# console application for the Flourish & Blotts scenario. It uses an enum menu, reusable methods, simple classes, and `List<Book>` to manage a customer’s active rental cart. The program supports adding customers, adding books, renting multiple books, calculating a checkout total, applying a time-based discount, showing earned coupons, awarding magical books, resetting the cart, serving another customer, and exiting.

The supplied brief repeatedly refers to books and rentals, although one later sentence says “various media” and “orders”. This solution follows the specific Flourish & Blotts book-rental story because it is more consistent with the rest of the brief.

## How to run

1. Install the .NET 8 SDK.
2. Open a terminal in this project folder.
3. Run `dotnet run`.
4. Replace the group-member placeholders in `Program.cs` before submitting.

The project is intentionally kept in one main source file so a beginner can follow the complete flow. In a larger application, the classes and business logic could be separated into additional files.

## Requirements addressed

| Brief requirement | Where it is implemented |
|---|---|
| C# console application | `FlourishAndBlotts.csproj` targets `net8.0` and `Program.cs` uses the console. |
| Enum-based navigation | `MenuChoice` and `ReadMenuChoice()`. |
| Enter customers | `EnterCustomer()`. |
| Add new books | `AddBookToCatalogue()`. |
| Rent multiple books | `RentBooks()` loops until the user chooses N. |
| Track items and costs | `Cart`, `CalculateSubtotal()`, and `decimal` prices. |
| Time-based discount | `GetTimeDiscountRate()`. |
| Rental-based coupons | `CalculateCoupons()`. |
| Magical bonuses | `GetMagicalRewards()`. |
| Checkout receipt | `Checkout()` prints books, subtotal, discount, total, coupons, and rewards. |
| Loop for multiple customers | The main `while` loop continues after checkout. |
| Reset the cart | `Cart.Clear()` and `currentCustomer = null` after a receipt is printed. |
| Exit option | `MenuChoice.Exit`. |
| Modularity and comments | Focused methods and explanatory code comments. |

## Project assumptions

The brief names the types of rules but does not provide exact numbers. The following assumptions are therefore stated openly rather than being hidden in the code:

- From 09:00 up to, but not including, 12:00, the customer receives a 10% discount.
- From 12:00 up to, but not including, 17:00, the customer receives a 5% discount.
- At all other times the discount is 0%. Only one time discount is applied; discounts do not stack.
- The customer earns one future-use coupon for every complete group of three rentals. Coupons are displayed, but they are not redeemed because the brief does not define a redemption value.
- At five rentals, the customer receives *The Monster Book of Monsters*. At eight or more rentals, the customer receives that book and *Fantastic Beasts and Where to Find Them*. These are free magical bonuses and do not increase the amount due.
- All prices are entered in the local currency and stored as `decimal`, which is suitable for money calculations.

If the lecturer or Milestone 1 specifies different values, only the relevant rule methods need to be changed.

## Pseudocode

```text
START
    Add three sample books to the catalogue
    REPEAT until the user chooses Exit
        Display enum-based menu
        Read and validate the menu number

        IF EnterCustomer
            Read a non-blank name and phone number
            Create the current customer
            Clear the cart

        ELSE IF AddBook
            Read a non-blank title and positive price
            Add a new book to the catalogue

        ELSE IF RentBooks
            Check that a customer exists
            Display the catalogue
            Add the selected book to the cart
            Ask whether another book should be rented

        ELSE IF Checkout
            Check that a customer and at least one rental exist
            Calculate subtotal
            Read the current time once
            Calculate the time discount and final amount
            Calculate coupons and magical rewards
            Display the receipt
            Clear the cart and current customer

        ELSE IF Exit
            Stop the loop
    END REPEAT
END
```

## Flow of the program

```text
[Start]
   |
[Show menu and read enum choice]
   |
[Enter customer]--[Add book]--[Rent books]--[Checkout]
       |              |             |             |
       +--------------+-------------+-------------+
                              |
                       [Cart reset after checkout]
                              |
                     [Return to menu or Exit]
```

## Why the main C# choices were made

An `enum` gives each menu option a readable name. `Enum.IsDefined` prevents an invalid number from being treated as a real menu option. The `Book` and `Customer` classes keep related data together, which is safer than keeping separate lists of titles and prices. The cart is a `List<Book>` because the customer may rent any number of books.

Money is stored using `decimal`, and receipt values use the `C2` format. Input methods use `TryParse` in loops. This prevents invalid text from crashing the program and separates input validation from the business rules.

The checkout method follows one clear sequence: subtotal, discount amount, final total, coupons, rewards, receipt, and reset. Printing the receipt before clearing the cart prevents the next customer from receiving the previous customer’s rentals.

## Research references

The design follows Microsoft Learn guidance on [C# enumerations][1], [methods][2], [classes][3], [generic lists][4], [time-of-day values][5], [decimal numeric types][6], [enum validation][7], [integer input validation][8], and [standard currency formatting][9]. The assignment requirements come from the supplied three-page PRG161 Milestone 2 brief.

## Submission checklist

Before submitting the ZIP file, replace the group-member and contribution placeholders, run the program from a clean terminal, complete the test cases in `TEST_PLAN.md`, and include the full project folder. Every group member should understand the entire program because the defense questions may cover any method.

[1]: https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/enum "C# enumeration types"
[2]: https://learn.microsoft.com/en-us/dotnet/csharp/programming-guide/classes-and-structs/methods "Methods (C# Programming Guide)"
[3]: https://learn.microsoft.com/en-us/dotnet/csharp/fundamentals/types/classes "Classes and objects (C# Programming Guide)"
[4]: https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.list-1?view=net-8.0 "List<T> Class"
[5]: https://learn.microsoft.com/en-us/dotnet/api/system.datetime.timeofday?view=net-8.0 "DateTime.TimeOfDay Property"
[6]: https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/floating-point-numeric-types "Floating-point numeric types (C# reference)"
[7]: https://learn.microsoft.com/en-us/dotnet/api/system.enum.isdefined?view=net-8.0 "Enum.IsDefined Method"
[8]: https://learn.microsoft.com/en-us/dotnet/api/system.int32.tryparse?view=net-8.0 "Int32.TryParse Method"
[9]: https://learn.microsoft.com/en-us/dotnet/standard/base-types/standard-numeric-format-strings "Standard numeric format strings"

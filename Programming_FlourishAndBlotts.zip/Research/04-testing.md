# Flourish & Blotts C# Milestone 2: Test Plan and 5-Minute Defense Guide

## Purpose

This plan helps a beginner demonstrate that the console application meets the Milestone 2 requirements: it uses an enum menu, accepts customers and books, rents more than one book, calculates totals and time-based discounts, reports rental-based coupons and magical rewards, resets the cart after checkout, loops for another customer, and exits safely. The assessment brief requires these behaviours but does **not** define the actual discount rate or time window, coupon threshold or reward, or magical-reward trigger. Therefore, replace the bracketed values below with the values used in the group's code before presenting. Do not invent a requirement that the code does not implement. [1]

> **Testing principle:** Test one rule at a time at its boundary, then test the rules together. For every calculation, write down the expected answer independently before running the program.

## 1. Prepare before testing

Use a clean run of the program for each test case unless the case explicitly tests repeated customers. Have a small test-data sheet beside you with the real constants and rules in the code.

| Item to record from the code | Example placeholder only | Why it matters |
|---|---:|---|
| Book prices | `12.50`, `20.00`, `7.50` | Lets you calculate the cart subtotal independently. |
| Discount time window and rate | `[eligible time]`, `[D%]` | Lets you make one qualifying and one non-qualifying test. |
| Coupon criterion and threshold | `[number of rentals or amount]`, `[C]` | Lets you test just below, exactly at, and just above the threshold. |
| Magical-reward trigger and award | `[trigger]`, `[reward book/title]` | Lets you prove both reward and no-reward paths. |
| Expected money format | e.g., two decimal places | Lets you spot price or rounding mistakes. |

If the program reads the current time automatically, run the qualifying discount test during the configured window. If the program accepts a time as input, enter a controlled time. Do not change the computer clock unless the lecturer permits it. If the code uses random magical rewards, test the deterministic trigger rather than promising a particular random title; if possible, explain how the code chooses one.

## 2. Expected calculation order

Write the actual rules next to this sequence. It makes your tests and explanation consistent.

1. Add every rented book price to form the **subtotal**.
2. Decide whether the time-based discount rule is eligible, then calculate the discount from the base that the code uses (normally the subtotal).
3. Calculate the **amount due** as the subtotal minus the discount, unless the program's stated rule also applies coupons as money off.
4. Check the coupon threshold. In this brief, coupons are described as **earned at checkout**; do not assume they reduce the current amount due unless that is in your implementation.
5. Check the magical-reward trigger and list the awarded book or books.
6. Display the item list, totals, discount, coupons, and magical rewards. Finally, clear the current cart before returning to the menu. [1]

For one calculation test, use this worksheet rather than relying on mental arithmetic:

```text
Book prices:             [p1] + [p2] + [p3] = subtotal [S]
Discount eligibility:    [yes/no]
Discount:                [S × D%] = [discount]     (if eligible)
Amount due:              [S − discount] = [total]
Coupon condition:        [rental count/amount] [comparison] [C] = [earned/not earned]
Magical condition:       [actual condition] = [award/no award]
```

Use `decimal` for currency in C# when the code is under your control. It represents base-10 money values more suitably than binary floating-point `double`, which can display small precision artefacts.

## 3. Manual test cases

Record **Pass** only when every expected result occurs. Capture a screenshot or copy the console output for the important checkout cases. Substitute the real menu labels, book data, thresholds, and rewards in the expected-result column.

| ID | Scenario and inputs | Expected result | Requirement evidenced |
|---|---|---|---|
| T01 | Start the program. Select each normal menu action in order: add a customer, add a valid book, rent it, then checkout. | The enum menu is shown; valid choices navigate correctly; the customer's book appears at checkout; subtotal, amount due, and all applicable messages appear. | Normal end-to-end flow; enum menu; checkout. |
| T02 | At the menu enter `abc`, blank input, `0`, and a number above the final enum choice. Then enter one valid choice. | Each invalid choice shows a helpful error and re-displays the menu. The program does not crash or accidentally perform an action. The later valid choice still works. | Invalid menu input; loop resilience. |
| T03 | At each data prompt enter blank text, letters where a number is required, a negative price/quantity, zero where it is disallowed, and an unrealistically large selection. Then give valid values. | The program rejects invalid input without adding a corrupt customer/book/cart entry. It explains what is required and accepts the corrected entry. | Input validation; accurate tracking. |
| T04 | Rent one valid book during a time that does **not** qualify for a discount and does not meet coupon or magical conditions. | The checkout lists that one title and its price. Subtotal equals its price, discount is `0`, amount due equals subtotal, and no unearned coupon/reward is displayed. | Baseline calculation; no false rewards. |
| T05 | Rent three or more books with different prices, for example `[12.50, 20.00, 7.50]`. Checkout without any trigger. | All titles are displayed once. Subtotal is the independent sum (`40.00` in the example); it is not only the last book's price. | Multiple-book cart; total accuracy. |
| T06 | Use the same cart at the exact first qualifying time (or date) for the time discount. Repeat one minute/unit before or after the boundary, depending on the rule. | At the boundary, the configured discount `[D%/rule]` is applied exactly once and amount due matches the worksheet. Outside it, the discount is absent. | Time-based discount; boundary testing. |
| T07 | Create carts that are just below, exactly at, and just above coupon threshold `[C]`. If the rule is rentals, use `[C-1]`, `[C]`, and `[C+1]` rentals. If it is total spend, use values just below/equal/above the amount. | No coupon below the threshold. The correct coupon appears at the threshold and remains correct above it. The coupon does not change the total unless the code explicitly says it does. | Rental-based coupon; threshold boundaries. |
| T08 | Make a cart that does not satisfy the magical condition, then a cart that satisfies it exactly. | The first checkout shows no magical book. The qualifying checkout lists the expected magical reward(s) from the Room of Requirement. Prices and totals change only if the project rule explicitly makes the reward chargeable. | Magical bonuses; no false positives. |
| T09 | Use a cart that qualifies for both the time discount and the coupon/reward condition(s). | The final checkout contains the complete book list, correctly calculated discount and amount due, earned coupon message, and magical reward message. None is overwritten by another output. | Combined business rules. |
| T10 | Complete checkout for Customer A with distinctive books. Immediately choose checkout again, or add Customer B and checkout with an empty/new cart. | Customer A's titles, prices, discount values, and rewards do not appear in Customer B's checkout. A checkout with no rental is handled safely with a clear message. | Cart reset; multiple customers; state isolation. |
| T11 | After T10, add/rent valid books for Customer B and checkout. | The application remains running, processes the new customer correctly, and only totals Customer B's current cart. | Required program loop for multiple customers. |
| T12 | Select the Exit enum option from a clean menu. Repeat after a checkout. | The program displays its farewell/closure message and terminates normally without an exception or another unwanted menu loop. | Exit behaviour. |

### Fast test log

Use one row per run. This shows a lecturer that you tested deliberately, not only by clicking through the program.

| Date | Test ID | Inputs / configured rule | Expected result | Actual result | Pass/Fail | Evidence or defect fixed |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

When a test fails, write the smallest reproduction steps, correct the code, and run the same test again. Also re-run T01, T05, and T10 after changes to totals or cart-clearing code because they can expose regressions.

## 4. A five-minute defense walkthrough

The aim is to **show a complete story** and explain the code's decisions, not to read every line. Prepare a command window, your code, and one completed calculation worksheet. Use valid sample data that triggers the strongest features. If a real-time discount cannot be reliably demonstrated in the timeslot, show the no-discount path live and explain the controlled boundary test with recorded evidence.

| Time | What to show | Suggested words |
|---:|---|---|
| 0:00–0:25 | State the purpose and map the menu. | “This is our Flourish & Blotts rental console application. It uses an enum-based menu and methods so a user can add customers and books, rent multiple books, checkout, start another customer, or exit.” |
| 0:25–1:00 | Show the `enum`, menu-display method, and selection/validation method. | “The enum gives each menu choice a named value instead of unexplained numbers. We validate the input before branching, so an invalid choice returns to the menu rather than crashing.” |
| 1:00–1:40 | Run add customer and add/rent books; show the cart collection/list. | “Each successful rental is stored in the current cart with its price. Adding another book does not overwrite the first one, so the checkout can list every rented book and calculate the subtotal.” |
| 1:40–2:35 | Open the checkout/calculation method and run a multi-book checkout. | “Checkout loops through the cart to display each book and add its price. The subtotal is separate from the discount and final amount due. This makes the calculation traceable.” |
| 2:35–3:15 | Point to the discount, coupon, and magical-reward conditions. | “The time check decides whether the configured discount applies. The coupon test uses the threshold `[C]`, and the magical rule has its own condition. We display earned coupons and rewards separately so they are not confused with the money discount.” |
| 3:15–3:55 | Show/reset code and new customer evidence. | “After the receipt is displayed, we clear or replace the current cart. I verified this by checking out Customer A, then Customer B: A’s books do not carry over.” |
| 3:55–4:35 | Demonstrate invalid input and Exit. | “For invalid input, the program shows an error and keeps running. The Exit enum value ends the loop cleanly.” |
| 4:35–5:00 | Finish with test evidence and team/code ownership. | “We tested normal, invalid, boundary, combined-rule, reset, and exit paths. These comments identify group contributions, but every member understands the full flow and can explain it.” |

### Before the defense

Run T01, T05, T09 or the closest deterministic combined test, T10, and T12 once on the machine you will use. Prepare exact code locations for the enum, the main loop, input validation, cart storage, calculation, reward conditions, and cart reset. Do not claim an automated test suite if you only performed manual tests; say “manual test cases” and show your log. Make sure comments identify group members and explain important blocks, as requested in the brief. [1]

## 5. Likely lecturer questions and short answers

| Question | Short answer to adapt to the actual code |
|---|---|
| Why did you use an enum for the menu? | “It gives each option a meaningful name, limits choices to the defined menu values, and makes the switch/branching easier to read than raw numbers.” |
| How do you stop invalid menu input from crashing the program? | “We parse/validate the input before using it. If parsing or range validation fails, we print an error and return to the menu; we do not index a list or cast blindly.” |
| Why are methods important here? | “Methods separate responsibilities. For example, one method displays the menu, another validates input, another adds a rental, and another checks out. This avoids repeated code and makes testing easier.” |
| How do you store multiple books? | “Each rental is added to the current cart collection/list. Checkout iterates over that collection, so every book contributes to the displayed receipt and subtotal.” |
| What is the difference between subtotal, discount, and total due? | “Subtotal is the sum of rental prices. Discount is the reduction when the time rule qualifies. Total due is the subtotal after the applicable monetary discount.” |
| How do you prove the discount is correct? | “I independently add the prices, apply the configured rate only at the qualifying time, and test the exact time boundary and a non-qualifying time.” |
| How did you test the coupon threshold? | “I ran three boundary cases: just below the threshold, exactly at it, and just above it. The coupon appears at the first qualifying point only.” |
| Does a coupon automatically reduce this bill? | “Not in our implementation unless explicitly coded. The brief requires the program to show coupons earned, so we keep that reward separate from the amount due.” |
| How are magical rewards chosen? | “The reward condition is checked independently at checkout. When it is true, the program lists the configured/selected Room of Requirement book; otherwise it lists none.” |
| What stops Customer A’s books appearing for Customer B? | “The checkout finishes by clearing or creating a new current-cart list. We tested a second checkout and confirmed that old entries no longer appear.” |
| What happens if checkout is selected with an empty cart? | “The program detects that there are no rentals, gives a clear message, and returns safely. It does not calculate a misleading receipt or crash.” |
| Why use `decimal` rather than `double` for prices? | “Currency is decimal. `decimal` helps avoid binary floating-point display/rounding surprises when adding money values.” |
| What happens when Exit is selected? | “The main loop’s running condition is changed or the exit case returns, so the program ends cleanly rather than continuing to show the menu.” |
| Which work did each group member do? | “We documented individual contributions in code comments. I can explain the whole program, including the parts other members implemented.” |

## 6. Final presentation checklist

Confirm that names/contributions are commented in the code; menu values are enum values; each reusable action is in a sensible method; money and cart state use the correct variables; empty and invalid input are safe; the receipt lists all rented books; formula outputs match an independent worksheet; threshold edges are tested; checkout clears the cart; a new customer works; and Exit terminates normally. These checks directly cover the practical and technical requirements stated in the milestone brief. [1]

## References

[1]: file:///home/ubuntu/upload/PRG161%5B2025%5DMilestone2%283%29.pdf "Programming 161 Milestone 2 assignment brief (provided PDF, pp. 1–3)"

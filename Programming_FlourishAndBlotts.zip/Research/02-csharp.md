# C# Console App Research Notes: Flourish & Blotts Rental Checkout

**Purpose.** These notes cover the beginner C# constructs needed for the PRG161 Milestone 2 console application: an enum-based menu, reusable methods, book and customer classes, a `List<T>` cart, time discounts, currency totals, and resilient console input. The assignment requires the app to enter customers and books, rent multiple books, calculate discounts and rewards at checkout, reset the cart, loop for more customers, and exit.

## Recommended program shape

Keep the main loop small. It should create a fresh cart for one customer, repeatedly show the menu and process a valid choice, then call one checkout method that prints the receipt and clears or replaces the cart. Keep each responsibility in a method: `ShowMenu`, `ReadMenuChoice`, `AddBookToCart`, `CalculateDiscount`, `Checkout`, and `ReadRequiredText` / `ReadPositiveDecimal`. This directly supports the brief's requirement to use methods for reusable code.

Use domain classes only for data that belongs together. For example, a `Book` can own its title and decimal rental price; a `Customer` can own a name and member number. Keep the cart as `List<Book>`. Calculate the subtotal from the current cart rather than maintaining an unrelated total that can become out of sync.

## 1. Enum menus

An `enum` is a value type made of named integral constants. It suits a mutually exclusive main-menu choice, such as `AddCustomer`, `AddBook`, `Checkout`, and `Exit`. Give every menu item an explicit number that matches what is printed. Include a zero value such as `None = 0`; Microsoft notes that an enum's default value is zero even when no member has that value, which otherwise can create an invalid value. [1]

```csharp
enum MenuChoice
{
    None = 0,
    EnterCustomer = 1,
    RentBook = 2,
    Checkout = 3,
    Exit = 4
}
```

Print numbered labels for people, then use a `switch` on the validated `MenuChoice`. For numeric input, first use `int.TryParse`, cast only after parsing, then call `Enum.IsDefined` to ensure the number actually belongs to the enum:

```csharp
static MenuChoice ReadMenuChoice()
{
    while (true)
    {
        Console.Write("Choose an option: ");
        if (int.TryParse(Console.ReadLine(), out int number) &&
            Enum.IsDefined(typeof(MenuChoice), number))
        {
            return (MenuChoice)number;
        }
        Console.WriteLine("Please enter a menu number that is shown.");
    }
}
```

`int.TryParse` reports success with a Boolean rather than throwing for malformed text. [10] `Enum.IsDefined` reports whether an integral value or name exists in an enumeration. [9] Do not rely on `(MenuChoice)number` alone: an explicit cast can create an enum value that has no named member. Do not use `[Flags]` for this ordinary one-choice menu; flags are for combinable bit fields. Do not confuse a menu enum with a price list: enum members have integral values, so book prices belong in `decimal` fields or a catalogue, not in the enum.

It is also possible to use `Enum.TryParse<MenuChoice>(input, true, out choice)` for typed names such as `Checkout`; the method can be case-insensitive and returns whether conversion succeeded. [8] It may accept numeric text too, so still confirm `Enum.IsDefined(choice)` if valid named members are required.

## 2. Methods

A method is a named block of statements that runs when it is called. Each executed C# instruction runs in a method; `Main` is the application entry point. [2] Give a method one clear responsibility and use parameters for the information it needs. Use `void` when it only performs an action, and a non-`void` return type when the caller needs a result.

```csharp
static decimal CalculateSubtotal(List<Book> cart)
{
    decimal subtotal = 0m;
    foreach (Book book in cart)
    {
        subtotal += book.RentalPrice;
    }
    return subtotal;
}

static bool IsDiscountTime(DateTime now)
{
    TimeSpan start = new TimeSpan(14, 0, 0);
    TimeSpan end = new TimeSpan(16, 0, 0);
    return now.TimeOfDay >= start && now.TimeOfDay < end;
}
```

Method parameter types must be compatible with the values supplied by the caller. A non-`void` method must return a matching type on every possible path. [2] Beginner mistakes are copying the same input or receipt code into many branches, calculating a value in a local variable but never returning it, declaring methods inside `Main`, or changing a price passed by value and expecting the caller's decimal variable to change. Passing a `List<Book>` or other class object passes a copy of the reference; changing the collection through it changes the same underlying collection. [2]

## 3. Classes and objects

A class is a reference-type blueprint for objects. The `new` keyword creates an instance, while a class variable holds a reference to that object. Assigning one class variable to another copies the reference, so both variables can refer to the same object. [3]

```csharp
class Book
{
    public string Title { get; set; }
    public decimal RentalPrice { get; set; }

    public Book(string title, decimal rentalPrice)
    {
        Title = title;
        RentalPrice = rentalPrice;
    }
}

class Customer
{
    public string Name { get; set; }

    public Customer(string name)
    {
        Name = name;
    }
}
```

Create a book with `new Book(title, price)` and add that object to the cart. A constructor ensures key data is supplied at creation. Use properties instead of unrelated parallel lists such as one list of titles and another list of prices; parallel lists are easy to misalign. Avoid assigning a cart variable to a "new cart" variable when an independent cart was intended: because `List<T>` is a class, both variables would point at the same list. For the next customer, use `cart = new List<Book>()` or call `cart.Clear()` after the receipt has used its contents.

## 4. `List<T>` as the rental cart

`List<T>` stores a sequence of one specified type, so `List<Book>` is appropriate for the current rental cart. Add each selected book with `cart.Add(book)`, use `cart.Count` for rental-based coupon rules, loop through it using `foreach`, and use `Clear()` after checkout. The API defines `Clear()` as removing all list elements; `Remove` removes the first matching object, while `RemoveAt` removes by zero-based index. [4]

```csharp
List<Book> cart = new List<Book>();
cart.Add(new Book("The Standard Book of Spells", 35.00m));

foreach (Book book in cart)
{
    Console.WriteLine($"{book.Title,-35} {book.RentalPrice:C2}");
}
```

Check `cart.Count == 0` before checkout and print a useful message rather than generating an empty receipt. Common mistakes are declaring the cart inside the menu loop (it resets after every choice), forgetting to reset it after checkout (the next customer pays for the previous customer), and removing elements inside `foreach` (this causes a runtime error). If removal is needed, first find a valid index and use `RemoveAt`, or use a backwards `for` loop.

## 5. `DateTime` and time-based discounts

Take the current local date/time once at checkout: `DateTime now = DateTime.Now;`. For a daily discount window, compare `now.TimeOfDay` to `TimeSpan` boundaries. `TimeOfDay` returns a `TimeSpan` representing the elapsed fraction of the day since midnight. [6] For example, a 14:00–16:00 promotion should normally include the start and exclude the end: `now.TimeOfDay >= start && now.TimeOfDay < end`. State that rule in a comment so it is testable.

For comparisons involving two complete `DateTime` values, `DateTime.Compare(t1, t2)` returns less than zero when the first is earlier, zero when equal, and greater than zero when later. [5] Its documentation warns that it compares ticks while ignoring `Kind`; ensure both values represent the same time zone before comparing them. [5] That concern is usually avoided in a beginner, local console app by comparing `DateTime.Now.TimeOfDay` to `TimeSpan` values. Do not compare formatted time strings such as `"2:00 PM"`; string order is not a reliable time comparison. Do not call `DateTime.Now` repeatedly when the same checkout decision must be consistent; pass one captured `now` value to the calculation and receipt methods.

## 6. `decimal` for rental prices and currency output

Store book prices, totals, discounts, and final amount due as `decimal`. Microsoft identifies `decimal` as appropriate for values whose precision depends on digits right of the decimal point, including currency, and explains that `double` and `float` can introduce unexpected rounding errors for decimal data. [7] Decimal literals need an `m` or `M` suffix, for example `35.00m` and `0.10m`; a literal without it is a `double`. [7]

```csharp
decimal subtotal = CalculateSubtotal(cart);
decimal discountRate = IsDiscountTime(now) ? 0.10m : 0m;
decimal discountAmount = subtotal * discountRate;
decimal amountDue = subtotal - discountAmount;
Console.WriteLine($"Total due: {amountDue:C2}");
```

The standard `C` format specifier displays a currency value using the current culture; `C2` requests two decimal places. [11] The visible currency symbol and separators depend on the machine's culture, so do not hard-code a dollar sign if the app must display the local currency. Do not mix `decimal` with `double` or `float` in arithmetic without explicit conversion: C# does not implicitly mix them. [7] Do not use `int` for totals, because it loses cents. Apply each discount once, retain `subtotal`, `discountAmount`, and `amountDue` as separate values, and never allow a percentage intended as 10% to be entered as `10m` without dividing by 100.

## 7. Console input validation

`Console.ReadLine()` reads one line and returns a `string?`; it returns `null` when no more lines are available. [12] Treat all text input as untrusted. Reject null, blank, and whitespace-only names. For numeric input, use a loop with `int.TryParse` or `decimal.TryParse`, then separately validate business rules such as a positive price or menu range. `decimal.TryParse` returns `false` rather than throwing if input is null, empty, malformed, or outside the decimal range. [13]

```csharp
static decimal ReadPositivePrice()
{
    while (true)
    {
        Console.Write("Rental price: ");
        if (decimal.TryParse(Console.ReadLine(), out decimal price) && price > 0m)
        {
            return price;
        }
        Console.WriteLine("Enter a positive amount, for example 35.00.");
    }
}

static string ReadRequiredText(string prompt)
{
    while (true)
    {
        Console.Write(prompt);
        string? text = Console.ReadLine();
        if (!string.IsNullOrWhiteSpace(text))
        {
            return text.Trim();
        }
        Console.WriteLine("This value is required.");
    }
}
```

Common mistakes are using `int.Parse`/`decimal.Parse` directly on arbitrary user input (which can throw), accepting a successfully parsed but invalid value such as `-5.00m`, and assuming `Console.ReadLine()` cannot be null. Parsing is not the same as validation: first confirm the text is a number, then confirm the number obeys the assignment's rules. `TryParse` uses culture-sensitive parsing by default, so show example input that matches the computer's locale or deliberately specify a culture only if the project requires a fixed format.

## Suggested checkout sequence

1. Confirm a current customer exists and `cart.Count > 0`.
2. Capture `DateTime now = DateTime.Now` once.
3. Calculate `subtotal` by summing the `decimal` `RentalPrice` of every `Book` in `cart`.
4. Use the time method and coupon rule based on `cart.Count` to calculate each reward exactly once. Keep the assignment's business thresholds in named constants or clearly commented methods.
5. Print each book, subtotal, discount amount, coupons/rewards, and final `amountDue` with `:C2`.
6. Start the next customer with a new `List<Book>` or call `Clear()` only after printing the receipt. Continue the menu loop unless the validated choice is `Exit`.

## References

[1]: https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/enum "Enumeration types (C# reference)"
[2]: https://learn.microsoft.com/en-us/dotnet/csharp/programming-guide/classes-and-structs/methods "Methods (C# Programming Guide)"
[3]: https://learn.microsoft.com/en-us/dotnet/csharp/fundamentals/types/classes "Classes (C# fundamentals)"
[4]: https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.list-1?view=net-10.0 "List<T> Class (System.Collections.Generic)"
[5]: https://learn.microsoft.com/en-us/dotnet/api/system.datetime.compare?view=net-10.0 "DateTime.Compare Method (System)"
[6]: https://learn.microsoft.com/en-us/dotnet/api/system.datetime.timeofday?view=net-10.0 "DateTime.TimeOfDay Property (System)"
[7]: https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/floating-point-numeric-types "Floating-point numeric types (C# reference)"
[8]: https://learn.microsoft.com/en-us/dotnet/api/system.enum.tryparse?view=net-10.0 "Enum.TryParse Method (System)"
[9]: https://learn.microsoft.com/en-us/dotnet/api/system.enum.isdefined?view=net-10.0 "Enum.IsDefined Method (System)"
[10]: https://learn.microsoft.com/en-us/dotnet/api/system.int32.tryparse?view=net-10.0 "Int32.TryParse Method (System)"
[11]: https://learn.microsoft.com/en-us/dotnet/standard/base-types/standard-numeric-format-strings "Standard numeric format strings"
[12]: https://learn.microsoft.com/en-us/dotnet/api/system.console.readline?view=net-10.0 "Console.ReadLine Method (System)"
[13]: https://learn.microsoft.com/en-us/dotnet/api/system.decimal.tryparse?view=net-10.0 "Decimal.TryParse Method (System)"

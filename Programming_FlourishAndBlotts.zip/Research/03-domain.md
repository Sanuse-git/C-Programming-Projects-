# Flourish & Blotts loyalty-rule interpretation

## Conclusion

The supplied Milestone 2 brief requires a C# console app to support **multiple book rentals**, track the cart and **total cost**, calculate **time-based discounts**, award **rental-based coupons**, and list **magical bonuses from the Room of Requirement** at checkout. It does not define prices, time bands, thresholds, coupon values, or bonus probabilities. The rules below are therefore a proposed implementation contract, not facts stated by the brief. They deliberately use only integer counts, decimal currency, and a single time lookup so that a first-year student can explain and test every result.

> The application must track “all rentals and total cost,” “time-based discounts,” “rental-based coupons,” and “magical bonuses,” and at checkout display rented books, calculate and apply the discount, show coupons earned, and list magical books awarded. [1]

## Data and scope

A **rental** is one selected book with a non-negative price. The cart may contain the same title more than once; each selection is a separate rental because the brief requires multiple rentals but does not prohibit duplicates. Store each selection in a `List<Book>` (or `List<Rental>`). A `Book` needs at least `Title` and `decimal RentalPrice`.

Use `decimal` for money, never `double`. The checkout is complete only when the user selects the checkout menu option. Cart-level outcomes are calculated once at checkout, then the cart is cleared before the next customer. Customer registration can remain a simple name/identifier for this milestone; no account history is needed because the brief only requires the current rental cart and reset after checkout.

Invalid book prices (less than zero) are rejected. An empty cart cannot be checked out. A zero-price book is permitted and counts as a rental, although it adds nothing to cost; this keeps “number of rentals” distinct from money spent.

## Calculation order

Calculate the outcomes in this fixed sequence. It prevents ambiguity and makes the receipt easy to explain.

1. `rentalCount` is the number of books in the cart.
2. `subtotal` is the sum of every rental price.
3. The current local clock determines exactly one time-discount rate.
4. `discountAmount = Round(subtotal * discountRate, 2)`.
5. `totalDue = subtotal - discountAmount`.
6. Coupons and magical bonus books are earned from `rentalCount`, not from the amount due and not from a discounted total.
7. Display the cart, subtotal, rate and discount amount, total due, coupons, and bonus books. Reset the cart only after this display.

The time discount affects cash due only. It does not change the rental count, coupon count, or eligibility for Room of Requirement rewards. This is a deliberate fairness rule: customers with identical carts get the same non-cash rewards regardless of the hour.

## Proposed time-based discount

Take the time once, when checkout begins: `DateTime.Now.TimeOfDay`. Use the following non-overlapping bands. The start time is included and the end time is excluded. A checkout at 12:00 receives the second rate, for example.

| Checkout time (local) | Discount rate | Rationale |
|---|---:|---|
| 09:00 inclusive to 12:00 exclusive | 10% | Morning reward |
| 12:00 inclusive to 17:00 exclusive | 5% | Standard daytime reward |
| Any other time | 0% | No time promotion |

This includes a defined default for after-hours testing and avoids relying on the machine time being within shop hours. If the team prefers to enforce opening hours, that is a separate validation rule and should not silently alter the rate.

A beginner-readable method is:

```csharp
static decimal GetTimeDiscountRate(DateTime checkoutTime)
{
    TimeSpan time = checkoutTime.TimeOfDay;

    if (time >= new TimeSpan(9, 0, 0) && time < new TimeSpan(12, 0, 0))
        return 0.10m;
    if (time >= new TimeSpan(12, 0, 0) && time < new TimeSpan(17, 0, 0))
        return 0.05m;

    return 0.00m;
}
```

## Proposed rental-based coupons

Award **one coupon for each complete group of three rentals**:

```text
couponsEarned = rentalCount / 3
```

C# integer division intentionally discards an incomplete group. Thus 0–2 rentals earn 0 coupons, 3–5 earn 1, and 6–8 earn 2. A coupon is a reward **earned for a future transaction**. It has no currency value in this milestone and is not deducted from the current checkout; the brief asks to show coupons earned, but gives no redemption rule. This avoids an unexplained second discount and lets the team simply display `Coupons earned today: X`.

## Proposed Room of Requirement magical bonuses

Award a fixed bonus book by rental-count tier. The title is deterministic, not random, so a result can be predicted before coding and demonstrated reliably during the project defense.

| Rentals in current cart | Bonus awarded |
|---:|---|
| 0–4 | None |
| 5–7 | *The Monster Book of Monsters* |
| 8 or more | *The Monster Book of Monsters* and *Fantastic Beasts and Where to Find Them* |

The higher tier **includes** the lower-tier book. This is a cumulative tier rule, not a choice between rewards. The bonus books are gifts, have price `0.00`, never appear in the paid rental subtotal, and are not added to the cart’s rental count. They are shown under a separate “Room of Requirement bonuses” heading. This prevents a bonus from generating additional coupons or recursively unlocking another bonus.

A readable implementation can use `List<string>`:

```csharp
static List<string> GetMagicalBonuses(int rentalCount)
{
    List<string> bonuses = new List<string>();

    if (rentalCount >= 5)
        bonuses.Add("The Monster Book of Monsters");
    if (rentalCount >= 8)
        bonuses.Add("Fantastic Beasts and Where to Find Them");

    return bonuses;
}
```

## Worked examples

| Cart prices | Checkout time | Count | Subtotal | Rate | Discount | Total due | Coupons | Magical bonuses |
|---|---|---:|---:|---:|---:|---:|---:|---|
| 20.00, 30.00 | 10:15 | 2 | 50.00 | 10% | 5.00 | 45.00 | 0 | None |
| 10.00, 10.00, 10.00 | 14:00 | 3 | 30.00 | 5% | 1.50 | 28.50 | 1 | None |
| Five books at 12.00 | 18:30 | 5 | 60.00 | 0% | 0.00 | 60.00 | 1 | *The Monster Book of Monsters* |
| Eight books at 25.00 | 09:00 | 8 | 200.00 | 10% | 20.00 | 180.00 | 2 | Both bonus titles |

## Assumptions to state in code comments/readme

1. The brief provides the feature categories but **no numerical business rules**. The rates, thresholds, titles, and coupon redemption approach above are documented project assumptions.
2. “Time-based” means the local computer time at the start of checkout, rather than rental start time or per-book timing. The time is read once so the result cannot change during a checkout.
3. Only one time-discount band applies; discounts do not stack.
4. Each cart is independent. The required post-checkout reset means no cumulative customer history, unused coupon balance, or bonus inventory is persisted.
5. Coupons are displayed as rewards for a later visit. They do not reduce this invoice unless the specification is later extended with coupon redemption rules.
6. Magical rewards are deterministic gifts, not paid rentals and not random draws. They therefore do not affect the subtotal, discount, coupon count, or reward eligibility.
7. Currency is rounded to two decimal places with `decimal.Round(value, 2, MidpointRounding.AwayFromZero)` if a rounding policy must be explicit. For the simple example rates, ordinary two-decimal display will usually suffice, but all money should remain `decimal`.

## Minimal testing checklist

Test the exact time boundaries 08:59, 09:00, 11:59, 12:00, 16:59, and 17:00. Test 0, 2, 3, 5, 7, and 8 rentals. Verify that the cart total is the sum of all selected prices; that the discount is taken only from the subtotal; that 5 rentals award exactly one stated bonus; that 8 rentals award exactly two; and that checkout clears the cart before the next customer.

## References

[1]: file:///home/ubuntu/upload/PRG161%5B2025%5DMilestone2%283%29.pdf "PRG161 2025 Milestone 2 assignment brief"

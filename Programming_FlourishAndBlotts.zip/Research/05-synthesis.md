# PRG161 Milestone 2 — Senior Implementation Blueprint

**Purpose.** This blueprint turns the supplied PRG161 Milestone 2 brief into a deliberately small, demonstrable C# console application. It distinguishes what the brief explicitly requires from business rules that the group must confirm or document. The goal is a reliable first version that satisfies the assessed flow before optional extensions are attempted.

## Review conclusion

The minimum viable application is a **Flourish & Blotts book-rental checkout console program**. It uses an enum-based main menu and reusable methods. A user can create a customer, add books to an in-memory catalogue, rent more than one catalogue book to the current customer, and check out. Checkout prints every rented book, the subtotal, a time-based discount, coupons earned, Room of Requirement bonus books, and the amount due. It then clears the active cart and remains available for the next customer, with a clean Exit option. These are explicit requirements of the brief. [1]

The brief has one terminology conflict. Its primary practical repeatedly specifies **books** and **rentals**, including magical books awarded from the Room of Requirement. A later general instruction says “various media” and “order.” The recommended scope is therefore **books/rentals only** for the minimum viable build. This is the more specific scenario and directly supports the checkout requirement. Record this decision in the README and ask the lecturer whether generic media is expected. Do not add films, music, quantities, inventory availability, or persistence merely to cover the conflicting wording; those features increase risk without a stated marking benefit. If the lecturer confirms generic media is required, rename `Book` to `MediaItem` and preserve the same cart and checkout logic, while retaining books for the magical awards.

The brief does not state discount windows or rates, coupon thresholds or values, bonus triggers, persistence, tax, customer fields, or catalogue rules. [1] The proposed rule set below is a **documented fallback contract**, not an assignment fact. Replace it if the lecturer, Milestone 1 design, or group agreement specifies different values.

> **Implementation decision:** complete and test the core checkout lifecycle first. Add optional session history only after the required cart, calculations, reset, and validation work correctly.

## Requirement-to-feature map

| Brief requirement | Minimum implementation evidence | Completion condition |
|---|---|---|
| Enum navigation and Exit | `MenuChoice` enum with explicit displayed numbers; validated `switch` loop | Invalid choices return to the menu; `Exit` ends the loop normally. |
| Enter new customers | `Customer` with auto-assigned ID and nonblank name; one active customer | A customer can be made active before a rental. |
| Add new books | `Book` with ID, title, and `decimal` rental price in an in-memory catalogue | A valid new book can subsequently be selected for rental. |
| Rent multiple books | `List<Book>` active cart; add one selected catalogue item per rental | At least two selected books remain in the cart and appear on the receipt. |
| Accurate costs and time discount | Subtotal is re-calculated from the cart; one checkout time is captured; money uses `decimal` | Receipt shows subtotal, rate, discount amount, and amount due. |
| Coupons and magical bonuses | Separate methods based on the active cart’s rental count | Receipt shows each earned outcome and never charges bonus books. |
| Checkout display and cart reset | Receipt prints list and outcomes before reset | The next customer cannot see or pay for the earlier cart. |
| Methods and explanatory/contribution comments | Focused action and calculation methods; concise header/block comments | Code has no duplicated checkout logic and identifies group contributions. |

## Scope and state model

Use a small in-memory design. It is sufficient for a console milestone and avoids parallel lists that can lose the relationship between a title and its price.

| State | Minimum fields | Lifetime and purpose |
|---|---|---|
| `Book` | `Id`, `Title`, `RentalPrice` (`decimal`) | Stored in `List<Book> catalog` for the current program run. |
| `Customer` | `Id`, `Name` | `currentCustomer` represents the customer being served; a list of customers is optional. |
| Active cart | `List<Book> cart` | Contains the current customer’s selected rental entries only. It is cleared only after a successful receipt has been printed. |
| Optional transaction history | Customer ID, item-title snapshot, totals, checkout time | Not needed for the MVP. Add only if the group interprets “all rentals” as completed session history. |

Each selection is one rental. A title may appear more than once if selected more than once, because the brief does not prohibit duplicate rentals. The catalogue and active cart are different: **Add Book** creates a catalogue entry; **Rent Book** selects a catalogue entry into the cart. This reconciliation meets both “adding new books” and “renting multiple books” without incorrectly treating a one-off cart entry as permanent inventory.

Use one active customer and one active cart. Do not allow a new customer to silently replace a customer who has a non-empty cart. Instead, show “checkout or clear the current transaction first.” This prevents accidental loss of rentals. Adding books to the catalogue may be allowed at any time because it does not alter the cart.

The MVP is session-only. It does not save data to files or a database, track stock, rental dates, returns, taxes, coupon balances, or authentication. These are reasonable future features, but none is specified in the brief. [1]

## Recommended enum and console flow

Define the numbers once and print the same numbers in the menu:

```text
None = 0
EnterCustomer = 1
AddBook = 2
RentBook = 3
Checkout = 4
Exit = 5
```

The main loop should be simple: show the menu, read one validated enum choice, run one focused action, and repeat until `Exit`. Parse a numeric choice with `int.TryParse`, then require `Enum.IsDefined` before casting and switching. A direct enum cast is not validation because it can produce an unnamed value. [2] [3] The active cart must be created **outside** the menu loop so it survives several `RentBook` choices, then cleared after checkout.

A useful controlled flow is:

```text
Start → initialise catalogue, currentCustomer = null, empty cart
      → show/read validated enum menu
      → EnterCustomer | AddBook | RentBook | Checkout | Exit
      → return to menu unless Exit
```

`RentBook` first checks that `currentCustomer` exists and that the catalogue is not empty. It displays book IDs, accepts a valid ID, and adds the selected book to the cart. `Checkout` first checks both a current customer and `cart.Count > 0`. An empty-cart checkout must state why no receipt was produced and return safely to the menu.

## Method boundaries

Methods should have a single job. Actions can be `void`; calculations should return a result. This directly supports the brief’s modularity requirement and lets the group explain each responsibility in the defence. [1] [4]

| Method | Responsibility | Important input/output |
|---|---|---|
| `ShowMenu()` | Print the numbered choices | No business logic. |
| `ReadMenuChoice()` | Parse and validate menu input in a loop | Returns a defined `MenuChoice`. |
| `ReadRequiredText(prompt)` | Reject null, blank, and whitespace-only text | Returns trimmed text. |
| `ReadRentalPrice()` | Parse currency and apply the agreed price rule | Returns a `decimal`. |
| `EnterCustomer(...)` | Create/activate a valid customer | Must not discard a non-empty cart. |
| `AddBookToCatalog(...)` | Collect book data and add it to the catalogue | Assigns an ID. |
| `RentBook(...)` | Validate prerequisites and put a selected book in the cart | One call adds one rental. |
| `CalculateSubtotal(cart)` | Sum `RentalPrice` values | Returns `decimal`; do not maintain a separate drifting total. |
| `GetTimeDiscountRate(checkoutTime)` | Decide exactly one rate from an injected time | Returns `decimal` rate. |
| `GetCouponsEarned(rentalCount)` | Apply the coupon rule | Returns an `int`. |
| `GetMagicalBonuses(rentalCount)` | Return zero, one, or two bonus titles | Returns `List<string>`. |
| `Checkout(...)` | Guard, capture time once, calculate, print receipt, reset cart | Coordinates methods; it should not duplicate their rules. |

Capture `DateTime.Now` once at the beginning of `Checkout` and pass that value to the discount method and receipt. Compare `checkoutTime.TimeOfDay` with `TimeSpan` boundaries, not formatted time strings. The calculation method should accept a `DateTime` parameter so boundary tests can pass constructed times without changing the computer clock. [5]

## Proposed, replaceable loyalty-rule contract

Place these values in named constants or clearly labelled methods. The group should confirm them before coding and identify them as assumptions in the README and relevant comments.

1. **Money and calculation order.** Store each price, the subtotal, discount rate, discount amount, and amount due as `decimal`; do not use `double` or `float` for money. Calculate in this fixed order: rental count; subtotal; time rate; `discountAmount = Round(subtotal × rate, 2)`; `amountDue = subtotal − discountAmount`; coupons and bonus books from the original rental count; then display the receipt. Use `decimal.Round(..., 2, MidpointRounding.AwayFromZero)` if an explicit rounding policy is needed. Display monetary values with `C2`; the symbol follows the computer’s culture. [6] [7]

2. **Time discount.** Read the local computer time at checkout. Award one non-stacking rate: **10% from 09:00 inclusive to 12:00 exclusive**, **5% from 12:00 inclusive to 17:00 exclusive**, and **0% otherwise**. Thus 12:00 receives 5%, while 17:00 receives 0%. The discount affects only money due.

3. **Coupons.** Award one future-use coupon for each complete group of three current-cart rentals: `couponsEarned = rentalCount / 3`. Coupons are displayed but do not reduce the current bill because the brief defines no redemption amount or process. [1]

4. **Room of Requirement books.** At 0–4 rentals, award none. At 5–7, award *The Monster Book of Monsters*. At 8 or more, award that book plus *Fantastic Beasts and Where to Find Them*. These are deterministic, zero-cost gifts printed in a separate receipt section. Do not add them to the paid cart, subtotal, or rental count, or a reward could produce another reward.

5. **Price validation decision.** The research findings conflict on zero-price books: one recommends a positive-price input routine; another permits a zero-price rental. The brief does not decide. The lowest-risk MVP rule is **require `RentalPrice > 0m`** and show a validation message otherwise. If the group deliberately supports free rentals, change the rule to `>= 0m`, document that choice, and test that free rentals count for coupons/bonuses but add nothing to the subtotal. Negative prices must always be rejected.

6. **No unintended state.** The required reset clears the active cart after a successful checkout. It does not clear the catalogue. Coupons are not saved or redeemed in the MVP, and magical bonus books do not alter later transactions.

## Receipt and reset behaviour

A successful receipt should show the current customer identifier/name; every cart line with title and price; rental count; subtotal; the captured checkout time or applicable rate; discount amount; total due; coupon count; and a distinct Room of Requirement section that says `None` when no gift is earned. It is helpful to display the rate even when it is 0%, because this makes the time rule auditable.

Only after the receipt is fully calculated and printed should the program run `cart.Clear()` (or replace it with a new `List<Book>`). Set `currentCustomer` to `null` if each checkout represents a fully completed customer interaction; this is recommended because it prevents an accidental rental under the prior customer’s name. Keep the catalogue intact. Never clear the cart before the receipt, and never reset it merely because an invalid checkout was attempted. `List<T>` supports adding items, reading its `Count`, iterating for the receipt, and `Clear()` for the specified reset. [8]

## Minimum validation rules

Validation is part of correctness rather than an optional enhancement. `Console.ReadLine()` can return null, and successful parsing alone does not prove that a value obeys the program’s business rules. [9] [10]

| Input or state | Required response |
|---|---|
| Menu text, blank input, `0`, or an undefined number | Explain that a displayed menu number is required; re-prompt without action. |
| Customer name blank or whitespace | Reject and re-prompt; trim accepted text. |
| New customer while cart has rentals | Keep current state and require checkout or an explicit, separately confirmed cancellation policy. |
| Book title blank | Reject and re-prompt. |
| Price text malformed, negative, or zero under the recommended policy | Reject and re-prompt; do not add the book. |
| Rent before customer exists | Explain the prerequisite; leave cart unchanged. |
| Rent when the catalogue is empty | Explain the prerequisite; leave cart unchanged. |
| Unknown/non-numeric book ID | Re-display selection or re-prompt; leave cart unchanged. |
| Checkout without current customer or with an empty cart | Explain why checkout cannot proceed; do not print a misleading receipt or clear unrelated state. |

Use `int.TryParse`/`decimal.TryParse` in loops, then validate the parsed range or business constraint separately. [3] [10] Do not use `Parse` on arbitrary console text where an exception would interrupt the program.

## Minimum manual acceptance suite

Run a clean program for each calculation case and retain console screenshots or a completed test log. In the table, the expected figures use the proposed contract above; replace them if the confirmed project rules change.

| ID | Inputs | Expected evidence |
|---|---|---|
| A1: core journey | Create customer; add catalogue books at 20.00 and 30.00; rent both; checkout at 10:15 | Both titles print; subtotal 50.00; 10% discount 5.00; amount due 45.00; 0 coupons; no bonus. |
| A2: multi-item total | Rent three differently priced books such as 12.50, 20.00, and 7.50 | Each appears once; subtotal is 40.00, proving the program did not retain only the latest price. |
| A3: coupon threshold | At 14:00, rent three books at 10.00 each | Subtotal 30.00; 5% discount 1.50; due 28.50; exactly 1 coupon. Also test 2 and 4 rentals. |
| A4: first magical tier | Rent five books at 12.00; checkout at 18:30 | Subtotal/due 60.00; 1 coupon; only *The Monster Book of Monsters*; gift is not charged. |
| A5: higher magical tier | Rent eight books at 25.00; checkout at 09:00 | Subtotal 200.00; 10% discount 20.00; due 180.00; 2 coupons; both configured gifts. |
| A6: time boundaries | Call/test discount calculation at 08:59, 09:00, 11:59, 12:00, 16:59, and 17:00 | Rates are respectively 0%, 10%, 10%, 5%, 5%, and 0%. |
| A7: bad input | Try text/blank/out-of-range menu choices; blank name/title; malformed, negative, and zero price; invalid book ID | Helpful messages; no crash; no invalid state or corrupt cart/catalogue entry. |
| A8: guards and reset | Attempt empty checkout. Then check out Customer A, create Customer B, and check out B’s new cart | Empty checkout is safe. A’s titles/totals/rewards do not appear for B. Catalogue remains usable. |
| A9: exit | Choose Exit before and after a completed checkout | Farewell/close message and normal termination; no further unwanted menu loop. |

## Implementation order and completion gate

First draw the menu/state flow using the group’s Milestone 1 pseudocode and flowchart. Then implement the enum menu, safe input helpers, customer creation, catalogue addition, and multiple-rental cart. Verify A1/A2 before adding calculation rules. Next implement pure subtotal, discount, coupon, and bonus methods, then the receipt and reset. Run A3–A9 after each relevant change. This order contains faults: a wrong subtotal is easier to find before loyalty rules are layered on top.

Before submission, add brief comments that name every group member and their contribution areas, plus comments for non-obvious state or loyalty-rule decisions. Comments should explain the reason for a rule, not narrate obvious syntax. Each member should rehearse the enum validation, `List<Book>` cart, calculation order, threshold boundaries, cart reset, and their test evidence because the brief requires an individual walk-through and questions on the whole program. Package the entire project folder in the required ZIP and follow the lecturer/LMS submission instructions. [1]

## Sources and related research

The supplied assignment brief is the authority for requirements. The proposed numerical loyalty rules and the implementation scope are project assumptions designed to close its omissions; they are not stated in the brief. The earlier detailed analyses remain useful working notes: `01-requirements.md`, `02-csharp.md`, `03-domain.md`, and `04-testing.md` in `/home/ubuntu/research/`.

## References

[1]: file:///home/ubuntu/upload/PRG161%5B2025%5DMilestone2%283%29.pdf "PRG161 2025 Milestone 2 assignment brief"
[2]: https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/enum "Enumeration types (C# reference)"
[3]: https://learn.microsoft.com/en-us/dotnet/api/system.enum.isdefined?view=net-10.0 "Enum.IsDefined Method (System)"
[4]: https://learn.microsoft.com/en-us/dotnet/csharp/programming-guide/classes-and-structs/methods "Methods (C# Programming Guide)"
[5]: https://learn.microsoft.com/en-us/dotnet/api/system.datetime.timeofday?view=net-10.0 "DateTime.TimeOfDay Property (System)"
[6]: https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/floating-point-numeric-types "Floating-point numeric types (C# reference)"
[7]: https://learn.microsoft.com/en-us/dotnet/standard/base-types/standard-numeric-format-strings "Standard numeric format strings"
[8]: https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.list-1?view=net-10.0 "List<T> Class (System.Collections.Generic)"
[9]: https://learn.microsoft.com/en-us/dotnet/api/system.console.readline?view=net-10.0 "Console.ReadLine Method (System)"
[10]: https://learn.microsoft.com/en-us/dotnet/api/system.decimal.tryparse?view=net-10.0 "Decimal.TryParse Method (System)"

# PRG161 Milestone 2 — Requirements Analysis

**Primary source:** `PRG161[2025]Milestone2(3).pdf` (3 pages; Programming 161, Milestone 2, 50 marks). Page references below refer to the supplied brief.

## Scope

Build a **C# console application** for Flourish & Blotts’ loyalty/rental cash-register scenario. The program must use enum-based navigation, accept customers and inventory items, support multi-item rentals/orders, calculate a payable total and loyalty/reward outcomes, and repeat for later customers while clearing the completed cart. The brief alternates between **books/rentals** and generic **media/orders**; implementation should choose one coherent model unless the lecturer clarifies otherwise.

## Explicit functional requirements

| ID | Requirement | Source |
|---|---|---|
| F1 | Provide navigation using an **enum-based menu system**. | p. 1 |
| F2 | Allow entry of **new customers**. | p. 1 |
| F3 | Allow addition of **new books**. | p. 1 |
| F4 | Allow a customer to **rent multiple books**. | p. 1 |
| F5 | Track **all rentals** and their **total cost**. | p. 1 |
| F6 | Calculate and apply **time-based discounts**. | p. 1 |
| F7 | Determine **rental-based coupons**. | p. 1 |
| F8 | Determine **magical bonuses**. | p. 1 |
| F9 | At checkout, display the list of rented books/items. | p. 1 |
| F10 | At checkout, calculate and apply the discount and show the resulting price due. | pp. 1–2 |
| F11 | At checkout, show coupons/rewards earned. | pp. 1–2 |
| F12 | At checkout, list magical books awarded from the **Room of Requirement**. | p. 1 |
| F13 | Support multiple customers by looping after transactions. | pp. 1–2 |
| F14 | Reset/clear the cart after every checkout. | pp. 1–2 |
| F15 | Give the user an option to close/exit the application. | pp. 1–2 |
| F16 | The later instructions also say that the program should allow ordering **various media** and track what was ordered and its cost. | p. 1 |

## Explicit technical and delivery requirements

| ID | Requirement | Source |
|---|---|---|
| T1 | Implement as a **C# console application**. | p. 1 |
| T2 | Use **enums for menu choices/navigation**. | p. 1 |
| T3 | Use **methods** to create menus and enforce modular, reusable code. | p. 1 |
| T4 | Keep cart contents and price tracking accurate. | p. 1 |
| T5 | Include C# comments explaining code/functionality. | pp. 1–2 |
| T6 | Comments must list group-member names, identify/keep track of contributions, and explain relevant code blocks. | pp. 1–2 |
| T7 | Refer to the team’s pseudocode, flowcharts, and research materials while implementing. | p. 2 |
| T8 | Work in the allocated group of **3–4 students**, with the same members as Milestone 1; each person submits. | pp. 2–3 |
| T9 | Each member uploads the entire project folder as a **ZIP** and clearly indicates responsibility for parts of the milestone. | p. 3 |
| T10 | Be ready for an individual project defence: a five-minute project walk-through and ten-minute questioning; all members must attend and may be questioned on the entire project. | p. 2 |
| T11 | Work must be the group’s own work; plagiarism scanning is stated. | p. 3 |

## Important ambiguities to resolve before implementation

| Topic | What the brief omits or conflicts on | Beginner-safe decision / clarification to seek |
|---|---|---|
| Domain vocabulary | It specifies books/rentals in the main practical, but says various media/orders later. | Ask whether the required domain is **books rented** only or a generic media order system. Until clarified, name the menu and checkout consistently around book rentals; do not silently claim unsupported media features. |
| Customer fields | “Entering new customers” has no required fields, validation, IDs, or storage rules. | Define a minimum record such as customer name plus a simple customer number, document the choice, and validate nonblank name/unique ID within the run. |
| Book fields | No fields, inventory limits, quantity, rental duration, or price rule is specified. | Decide and document a minimum book title and rental price. Add author/ID/availability only if the group’s Milestone 1 design requires them. |
| Adding books vs renting | It is unclear whether books are an in-memory catalog, a one-off cart entry, or persistent inventory. | Use a small in-memory catalog with a menu option to add books, then select catalog books into the active customer’s cart. State that data lasts only for the program run unless persistence is explicitly requested. |
| Discount rule | “Time-based discounts” does not define time source, time bands, rates, eligibility, or whether it applies before/after rewards. | Obtain the expected formula. If none is provided, agree on simple, documented clock-time bands/rates and apply one clearly stated discount to the subtotal. |
| Coupons | “Rental-based coupons” gives no threshold, count rule, coupon value, expiration, or whether coupons reduce today’s bill. | Treat coupons as an earned checkout reward rather than a price reduction unless told otherwise; document threshold and message. |
| Magical bonuses | No trigger, selection list, quantity, or duplicate behavior is defined for Room of Requirement books. | Agree on a deterministic trigger and fixed award list so the output is testable; distinguish these free awards from rented books. |
| “All rentals” | Could mean the current cart, transaction history for the session, or all time. | Maintain both an active cart (cleared at checkout) and optional session history if the team interprets “all” literally. Do not clear the catalog merely because the cart resets. |
| Checkout formula | Tax, currency format, discount rounding, invalid input, free items, and negative prices are unspecified. | Use non-negative monetary values, `decimal` for prices, explicit currency formatting and a documented sequence: subtotal → discount → amount due. Ask whether tax is wanted; otherwise omit it. |
| Menu/input behavior | No exact menu items, numeric mapping, invalid-choice handling, cancellation, or exit timing is given. | Define enum values centrally; use a validation loop for choices; provide Checkout and Exit at the main menu; prevent checkout of an empty cart with a clear message. |
| Rubric and submission mechanics | The brief has 50 marks but no marking rubric, due date, file naming rule, or repository requirement. | Confirm these with the lecturer/LMS before final packaging. |

## Beginner-friendly implementation checklist (no code)

1. **Agree on the business rules first.** Record the exact customer fields, book fields, sample rental prices, time-discount bands, coupon threshold, and magical-bonus trigger. Ask the lecturer about any rule that affects marks, particularly the book/media conflict and the reward formulae.
2. **Draw the console flow.** Start → main enum menu → add customer / add book / rent book(s) / checkout / exit. Include invalid-input loops and the post-checkout return to the main menu in the flowchart.
3. **Plan the smallest data model.** Separate a book/catalog item, a customer, an active cart (multiple rented items), and an optional completed-rental history. Decide which values reset at checkout (cart and current total) and which persist during the run (catalog and, if used, history).
4. **List menu enums before building screens.** Use meaningful choices and include Checkout and Exit. Decide whether operations such as rent require a customer first, and display a helpful message when prerequisites are missing.
5. **Divide the application into small methods.** Plan one method for each menu screen/action, input validation, price/subtotal calculation, discount calculation, coupon calculation, magical-award calculation, checkout display, and cart reset. Keep each method focused on one job.
6. **Build the happy path in order.** Add a customer; add several books; add more than one book to the active cart; then display the cart and raw subtotal. Check each step manually before adding rewards.
7. **Add financial calculations carefully.** Keep individual prices and the subtotal in `decimal` values. Calculate subtotal once from the cart, calculate the stated discount, then calculate the final amount due. Display the calculation clearly and consistently.
8. **Add rewards as explicit, testable rules.** Verify a transaction below, at, and above each coupon/bonus threshold. Ensure rewards are shown at checkout and do not accidentally become rental charges unless that is the agreed rule.
9. **Finish the checkout lifecycle.** Verify it shows rented items, subtotal/discount/total due, coupons, and Room of Requirement awards; then clear the active cart and total. Start a second customer and confirm completed-cart items do not carry over.
10. **Test edge cases.** Test bad menu input, blank customer/book input, invalid or negative price, an empty cart checkout, one item and many items, boundary discount time, reward thresholds, and exit from the main menu.
11. **Document and prepare submission.** Add concise comments with all group names, responsibility areas, and non-obvious logic. Rehearse every member’s ability to explain the entire program, package the full project folder into a ZIP, and have every member submit the required file.

## Acceptance-test minimum

A demonstrable run should: create a customer; add/select at least two books; rent both; show each title and correct subtotal at checkout; apply the documented time discount; show the documented coupons and magical awards; display a correct amount due; reset the cart; accept a new customer without inherited cart items; and exit cleanly.

## Caveats

This document identifies requirements and safe planning choices only; it does **not** invent a mandatory discount/coupon/bonus formula. The supplied PDF does not provide those business rules, a rubric, a due date, or persistence requirements, so these need lecturer/group confirmation.

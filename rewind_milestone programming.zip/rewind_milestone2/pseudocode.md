# Rewind Milestone 2 — Pseudocode

This pseudocode matches the structure and method names of the accompanying C# program. Values marked **[PERSONALISE]** are group design decisions that the assignment brief does not define.

## Program-level algorithm

```text
START PROGRAM
    Display application title and personalisation reminder

    customer <- ReadCustomer()
    cart <- new empty list of OrderLine
    applicationIsRunning <- TRUE

    WHILE applicationIsRunning = TRUE
        choice <- ReadEnumChoice(MainMenuChoice)

        CASE choice OF
            OrderMedia:
                AddMediaToCart(cart)

            ViewCart:
                DisplayCart(cart)

            Checkout:
                checkoutCompleted <- Checkout(customer, cart)

                IF checkoutCompleted = TRUE THEN
                    ResetCart(cart)
                    nextStep <- ReadEnumChoice(AfterCheckoutChoice)

                    IF nextStep = StartNewOrder THEN
                        applicationIsRunning <- TRUE
                    ELSE
                        applicationIsRunning <- FALSE
                    END IF
                END IF

            ViewCustomerDetails:
                DisplayCustomer(customer)

            Exit:
                applicationIsRunning <- FALSE
        END CASE
    END WHILE

    Display closing message
END PROGRAM
```

## Customer entry and reusable enum menu

```text
METHOD ReadCustomer RETURNS Customer
    name <- ReadRequiredText("Customer name")
    loyaltyNumber <- ReadRequiredText("Loyalty number")
    tier <- ReadEnumChoice(CustomerTier)
    RETURN new Customer(name, loyaltyNumber, tier)
END METHOD

METHOD ReadRequiredText(prompt) RETURNS text
    REPEAT
        Display prompt
        input <- read and trim a console line
        IF input is not blank THEN
            RETURN input
        END IF
        Display required-field error
    FOREVER
END METHOD

METHOD ReadEnumChoice(enum type) RETURNS enum value
    REPEAT
        Display every defined numeric value and label in the enum
        input <- read a console line

        IF input is a whole number AND number is defined in the enum THEN
            RETURN the matching enum value
        END IF

        Display invalid-choice error
    FOREVER
END METHOD
```

## Add-media algorithm

```text
METHOD AddMediaToCart(cart)
    mediaType <- ReadEnumChoice(MediaType)

    IF mediaType = Back THEN
        RETURN without changing cart
    END IF

    matchingProducts <- all catalogue products of mediaType
    Display 0 for Back
    Display each matching product with a local selection number and unit price
    productChoice <- ReadIntegerInRange(0 through number of matching products)

    IF productChoice = 0 THEN
        RETURN without changing cart
    END IF

    quantity <- ReadPositiveInteger()
    selectedProduct <- matchingProducts[productChoice - 1]
    existingLine <- cart line with selectedProduct ID, if one exists

    IF existingLine exists THEN
        Increase its quantity by quantity
    ELSE
        Add a new OrderLine(selectedProduct, quantity) to cart
    END IF

    Display confirmation and CalculateSubtotal(cart)
END METHOD
```

## Checkout-calculation algorithm

> **[PERSONALISE: confirm these policies.]** Bronze gives 0%, Silver 5%, and Gold 10%. The R5 coupon requires an original subtotal of R50. The 10% coupon requires an original subtotal of R100. A R10 reward applies automatically at an original subtotal of R150. Coupon and reward deductions cannot reduce the payable amount below zero.

```text
METHOD CalculateCheckout(cart, tier, coupon) RETURNS CheckoutResult
    subtotal <- RoundMoney(CalculateSubtotal(cart))
    tierRate <- GetTierRate(tier)
    tierDiscount <- RoundMoney(subtotal * tierRate)
    afterTier <- subtotal - tierDiscount

    couponDiscount <- 0

    IF coupon = FiveRandOff THEN
        IF subtotal >= 50 THEN
            couponDiscount <- smaller of 5 and afterTier
            couponMessage <- eligible and applied
        ELSE
            couponMessage <- ineligible because subtotal is below 50
        END IF

    ELSE IF coupon = TenPercentOff THEN
        IF subtotal >= 100 THEN
            couponDiscount <- RoundMoney(afterTier * 10%)
            couponMessage <- eligible and applied after tier discount
        ELSE
            couponMessage <- ineligible because subtotal is below 100
        END IF

    ELSE
        couponMessage <- no coupon selected
    END IF

    afterCoupon <- afterTier - couponDiscount
    rewardDiscount <- 0

    IF subtotal >= 150 THEN
        rewardDiscount <- smaller of 10 and afterCoupon
        rewardMessage <- R10 reward earned and applied
    ELSE
        rewardMessage <- no reward because subtotal is below 150
    END IF

    finalTotal <- larger of 0 and RoundMoney(afterCoupon - rewardDiscount)

    RETURN CheckoutResult containing all amounts and messages
END METHOD
```

## Checkout, receipt, and reset

```text
METHOD Checkout(customer, cart) RETURNS Boolean
    IF cart has no lines THEN
        Display "Empty cart - add an item before checkout"
        RETURN FALSE
    END IF

    coupon <- ReadEnumChoice(CouponChoice)
    result <- CalculateCheckout(cart, customer tier, coupon)
    PrintReceipt(customer, cart, result)
    RETURN TRUE
END METHOD

METHOD PrintReceipt(customer, cart, result)
    Display customer name, loyalty number, and tier

    FOR EACH line IN cart
        Display media type, title, quantity, unit price, and line total
    END FOR

    Display subtotal
    Display tier rate and tier discount
    Display coupon discount and eligibility message
    Display reward credit and eligibility message
    Display final total due
END METHOD

METHOD ResetCart(cart)
    Clear every OrderLine from cart
    Display reset confirmation
END METHOD
```

## Data and validation decisions

| Decision | Pseudocode rule |
|---|---|
| Currency values | Use `decimal`, then round displayed calculation results to two decimals away from zero. **[PERSONALISE: confirm.]** |
| Blank text | Reject and repeat the prompt. |
| Menu number | Accept only a whole number that is defined by the displayed enum. |
| Product number | Accept only 0 through the number of displayed products. |
| Quantity | Accept only a whole number greater than zero. **[PERSONALISE: confirm.]** |
| End of input | Display a message and close normally rather than dereferencing a null line. |
| Duplicate product | Increase the existing cart-line quantity. **[PERSONALISE: confirm.]** |
| Empty checkout | Reject it and return to the main menu. |
| Successful checkout | Print receipt, then clear the cart before asking whether to continue. |

## References

The control flow implements the requirements in the supplied `PRG161[2024-08-07]Milestone2.pdf`. Microsoft explains that an enum is a value type made from named integral constants.[1]

[1]: https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/enum "Enumeration types — C# reference"

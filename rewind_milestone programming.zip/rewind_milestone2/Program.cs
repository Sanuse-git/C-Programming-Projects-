namespace RewindMilestone2;

// Programming 161 — Rewind Milestone 2
// Group members (replace every placeholder before submission):
// 1. [PERSONALISE: Member 1 full name and student number]
// 2. [PERSONALISE: Member 2 full name and student number]
// 3. [PERSONALISE: Member 3 full name and student number]
// Responsibility summary: [PERSONALISE: state each member's actual contribution].
// This starter must be understood, tested, and personalised by the group before it is submitted.

internal static class Program
{
    // Main is deliberately short: RewindStore coordinates the complete application workflow.
    private static void Main()
    {
        RewindStore.Run();
    }
}

using System.Globalization;

namespace RewindMilestone2;

internal static class RewindStore
{
    // [PERSONALISE] These catalogue titles and prices are design choices, not values supplied by the brief.
    private static readonly List<Product> Catalogue = new()
    {
        new Product(1, "Retro Adventure", MediaType.VHS, 25.00m),
        new Product(2, "Time Travellers", MediaType.VHS, 30.00m),
        new Product(3, "Future Classics", MediaType.DVD, 50.00m),
        new Product(4, "Comedy Night", MediaType.DVD, 39.99m),
        new Product(5, "Synthwave Hits", MediaType.CD, 25.00m),
        new Product(6, "Rock Anthems", MediaType.CD, 20.00m)
    };

    private static readonly CultureInfo RandCulture = CultureInfo.GetCultureInfo("en-ZA");

    // Runs customer entry once and then keeps showing the main menu until the user exits.
    public static void Run()
    {
        Console.WriteLine("========================================");
        Console.WriteLine("       REWIND LOYALTY CASH REGISTER");
        Console.WriteLine("========================================");
        Console.WriteLine("Student note: replace all [PERSONALISE] details and confirm the rules before submission.\n");

        Customer customer = ReadCustomer();
        List<OrderLine> cart = new();
        bool applicationIsRunning = true;

        while (applicationIsRunning)
        {
            MainMenuChoice choice = ReadEnumChoice<MainMenuChoice>("MAIN MENU");

            switch (choice)
            {
                case MainMenuChoice.OrderMedia:
                    AddMediaToCart(cart);
                    break;
                case MainMenuChoice.ViewCart:
                    DisplayCart(cart);
                    break;
                case MainMenuChoice.Checkout:
                    if (Checkout(customer, cart))
                    {
                        // Clearing the actual list prevents items and totals leaking into the next order.
                        ResetCart(cart);
                        AfterCheckoutChoice nextStep = ReadEnumChoice<AfterCheckoutChoice>("AFTER CHECKOUT");
                        applicationIsRunning = nextStep == AfterCheckoutChoice.StartNewOrder;
                    }
                    break;
                case MainMenuChoice.ViewCustomerDetails:
                    DisplayCustomer(customer);
                    break;
                case MainMenuChoice.Exit:
                    applicationIsRunning = false;
                    break;
            }
        }

        Console.WriteLine("Thank you for visiting Rewind. The application has closed.");
    }

    // Collects the required customer details and rejects blank text fields.
    private static Customer ReadCustomer()
    {
        Console.WriteLine("CUSTOMER ENTRY");
        string name = ReadRequiredText("Customer name: ");
        string loyaltyNumber = ReadRequiredText("Loyalty number: ");
        CustomerTier tier = ReadEnumChoice<CustomerTier>("SELECT CUSTOMER TIER");

        Console.WriteLine("\nCustomer details saved.\n");
        return new Customer(name, loyaltyNumber, tier);
    }

    // Displays every value in an enum and only returns a defined numeric choice.
    private static T ReadEnumChoice<T>(string heading) where T : struct, Enum
    {
        while (true)
        {
            Console.WriteLine($"\n--- {heading} ---");
            foreach (T option in Enum.GetValues<T>())
            {
                int number = Convert.ToInt32(option);
                Console.WriteLine($"{number}. {GetMenuLabel(option.ToString())}");
            }

            Console.Write("Choose an option: ");
            string input = ReadLineOrExit();

            if (int.TryParse(input, out int numberChosen) &&
                Enum.IsDefined(typeof(T), numberChosen))
            {
                return (T)Enum.ToObject(typeof(T), numberChosen);
            }

            Console.WriteLine("Invalid choice. Enter one of the displayed whole numbers.");
        }
    }

    // Converts enum member names into labels that are easier to read at the console.
    private static string GetMenuLabel(string enumName)
    {
        return enumName switch
        {
            "OrderMedia" => "Order media",
            "ViewCart" => "View cart",
            "ViewCustomerDetails" => "View customer details",
            "FiveRandOff" => "R5 off (requires a R50 subtotal)",
            "TenPercentOff" => "10% off (requires a R100 subtotal)",
            "StartNewOrder" => "Start a new order",
            _ => enumName
        };
    }

    // Lets the user choose a media category, product, and positive quantity.
    private static void AddMediaToCart(List<OrderLine> cart)
    {
        MediaType mediaType = ReadEnumChoice<MediaType>("MEDIA TYPE");
        if (mediaType == MediaType.Back)
        {
            return;
        }

        List<Product> matchingProducts = new();
        foreach (Product product in Catalogue)
        {
            if (product.Type == mediaType)
            {
                matchingProducts.Add(product);
            }
        }

        Console.WriteLine($"\n--- {mediaType} CATALOGUE ---");
        Console.WriteLine("0. Back");
        for (int index = 0; index < matchingProducts.Count; index++)
        {
            Product product = matchingProducts[index];
            Console.WriteLine($"{index + 1}. {product.Title} - {Money(product.UnitPrice)}");
        }

        int productChoice = ReadIntegerInRange("Choose a product: ", 0, matchingProducts.Count);
        if (productChoice == 0)
        {
            return;
        }

        int quantity = ReadPositiveInteger("Quantity: ");
        Product selectedProduct = matchingProducts[productChoice - 1];
        OrderLine? existingLine = cart.Find(line => line.Product.Id == selectedProduct.Id);

        if (existingLine is null)
        {
            cart.Add(new OrderLine(selectedProduct, quantity));
        }
        else
        {
            // Repeated selections are combined into one cart line with a larger quantity.
            existingLine.AddQuantity(quantity);
        }

        Console.WriteLine($"Added {quantity} x {selectedProduct.Title} to the cart.");
        Console.WriteLine($"Current subtotal: {Money(CalculateSubtotal(cart))}");
    }

    // Shows all cart lines and their running merchandise subtotal.
    private static void DisplayCart(List<OrderLine> cart)
    {
        Console.WriteLine("\n--- CURRENT CART ---");
        if (cart.Count == 0)
        {
            Console.WriteLine("The cart is empty.");
            return;
        }

        PrintOrderLines(cart);
        Console.WriteLine($"Subtotal: {Money(CalculateSubtotal(cart))}");
    }

    // Completes a non-empty order, prints its receipt, and reports success to the main loop.
    private static bool Checkout(Customer customer, List<OrderLine> cart)
    {
        if (cart.Count == 0)
        {
            Console.WriteLine("\nEmpty cart - add an item before checkout.");
            return false;
        }

        CouponChoice coupon = ReadEnumChoice<CouponChoice>("SELECT ONE COUPON");
        CheckoutResult result = CalculateCheckout(cart, customer.Tier, coupon);
        PrintReceipt(customer, cart, result);
        return true;
    }

    // Applies the documented sequence: tier discount, one coupon, then automatic reward credit.
    private static CheckoutResult CalculateCheckout(
        List<OrderLine> cart,
        CustomerTier tier,
        CouponChoice coupon)
    {
        decimal subtotal = RoundMoney(CalculateSubtotal(cart));
        decimal tierRate = GetTierRate(tier);
        decimal tierDiscount = RoundMoney(subtotal * tierRate);
        decimal afterTier = subtotal - tierDiscount;

        decimal couponDiscount = 0m;
        string couponMessage;

        if (coupon == CouponChoice.FiveRandOff)
        {
            if (subtotal >= 50m)
            {
                couponDiscount = Math.Min(5m, afterTier);
                couponMessage = "R5 coupon eligible and applied.";
            }
            else
            {
                couponMessage = "R5 coupon not applied: subtotal is below R50.";
            }
        }
        else if (coupon == CouponChoice.TenPercentOff)
        {
            if (subtotal >= 100m)
            {
                couponDiscount = RoundMoney(afterTier * 0.10m);
                couponMessage = "10% coupon eligible and applied after the tier discount.";
            }
            else
            {
                couponMessage = "10% coupon not applied: subtotal is below R100.";
            }
        }
        else
        {
            couponMessage = "No coupon selected.";
        }

        decimal afterCoupon = afterTier - couponDiscount;
        decimal rewardDiscount = 0m;
        string rewardMessage;

        if (subtotal >= 150m)
        {
            rewardDiscount = Math.Min(10m, afterCoupon);
            rewardMessage = "Earned and applied: R10 loyalty reward credit.";
        }
        else
        {
            rewardMessage = "No reward: subtotal is below R150.";
        }

        decimal finalTotal = Math.Max(0m, RoundMoney(afterCoupon - rewardDiscount));

        return new CheckoutResult
        {
            Subtotal = subtotal,
            TierRate = tierRate,
            TierDiscount = tierDiscount,
            CouponChoice = coupon,
            CouponDiscount = RoundMoney(couponDiscount),
            CouponMessage = couponMessage,
            RewardDiscount = RoundMoney(rewardDiscount),
            RewardMessage = rewardMessage,
            FinalTotal = finalTotal
        };
    }

    // Prints enough intermediate values for a student to explain and audit the checkout total.
    private static void PrintReceipt(
        Customer customer,
        List<OrderLine> cart,
        CheckoutResult result)
    {
        Console.WriteLine("\n========================================");
        Console.WriteLine("             REWIND RECEIPT");
        Console.WriteLine("========================================");
        Console.WriteLine($"Customer: {customer.Name}");
        Console.WriteLine($"Loyalty number: {customer.LoyaltyNumber}");
        Console.WriteLine($"Tier: {customer.Tier}");
        Console.WriteLine("----------------------------------------");
        PrintOrderLines(cart);
        Console.WriteLine("----------------------------------------");
        Console.WriteLine($"Subtotal:                 {Money(result.Subtotal),10}");
        Console.WriteLine($"Tier discount ({result.TierRate:P0}):  -{Money(result.TierDiscount),10}");
        Console.WriteLine($"Coupon discount:         -{Money(result.CouponDiscount),10}");
        Console.WriteLine($"  {result.CouponMessage}");
        Console.WriteLine($"Reward credit:           -{Money(result.RewardDiscount),10}");
        Console.WriteLine($"  {result.RewardMessage}");
        Console.WriteLine("----------------------------------------");
        Console.WriteLine($"TOTAL DUE:                {Money(result.FinalTotal),10}");
        Console.WriteLine("========================================");
    }

    // Reuses one cart-line format in both cart review and receipt output.
    private static void PrintOrderLines(List<OrderLine> cart)
    {
        foreach (OrderLine line in cart)
        {
            Console.WriteLine(
                $"{line.Product.Type,-3} | {line.Product.Title,-18} | " +
                $"{line.Quantity} x {Money(line.Product.UnitPrice)} = {Money(line.GetLineTotal())}");
        }
    }

    // Adds each line total using decimal currency arithmetic.
    private static decimal CalculateSubtotal(List<OrderLine> cart)
    {
        decimal subtotal = 0m;
        foreach (OrderLine line in cart)
        {
            subtotal += line.GetLineTotal();
        }

        return subtotal;
    }

    // [PERSONALISE] These tier rates are proposed rules and must be confirmed by the group/lecturer.
    private static decimal GetTierRate(CustomerTier tier)
    {
        return tier switch
        {
            CustomerTier.Silver => 0.05m,
            CustomerTier.Gold => 0.10m,
            _ => 0m
        };
    }

    // Clears all order lines; checkout totals are local, so no monetary state remains to reset.
    private static void ResetCart(List<OrderLine> cart)
    {
        cart.Clear();
        Console.WriteLine("\nCheckout complete. The cart has been reset.");
    }

    private static void DisplayCustomer(Customer customer)
    {
        Console.WriteLine("\n--- CUSTOMER DETAILS ---");
        Console.WriteLine($"Name: {customer.Name}");
        Console.WriteLine($"Loyalty number: {customer.LoyaltyNumber}");
        Console.WriteLine($"Tier: {customer.Tier}");
    }

    // Repeats until non-blank text is entered.
    private static string ReadRequiredText(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string input = ReadLineOrExit().Trim();
            if (!string.IsNullOrWhiteSpace(input))
            {
                return input;
            }

            Console.WriteLine("This field is required. Please enter a value.");
        }
    }

    // Repeats until a whole number inside the requested inclusive range is entered.
    private static int ReadIntegerInRange(string prompt, int minimum, int maximum)
    {
        while (true)
        {
            Console.Write(prompt);
            string input = ReadLineOrExit();
            if (int.TryParse(input, out int value) && value >= minimum && value <= maximum)
            {
                return value;
            }

            Console.WriteLine($"Enter a whole number from {minimum} to {maximum}.");
        }
    }

    // Repeats until a quantity greater than zero is entered.
    private static int ReadPositiveInteger(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string input = ReadLineOrExit();
            if (int.TryParse(input, out int value) && value > 0)
            {
                return value;
            }

            Console.WriteLine("Quantity must be a whole number greater than zero.");
        }
    }

    // Treats end-of-input as a normal close instead of allowing a null-input crash.
    private static string ReadLineOrExit()
    {
        string? input = Console.ReadLine();
        if (input is null)
        {
            Console.WriteLine("\nInput stream closed. The application will exit.");
            Environment.Exit(0);
        }

        return input ?? string.Empty;
    }

    private static decimal RoundMoney(decimal value)
    {
        return Math.Round(value, 2, MidpointRounding.AwayFromZero);
    }

    private static string Money(decimal value)
    {
        return value.ToString("C2", RandCulture);
    }
}

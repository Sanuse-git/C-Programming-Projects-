namespace RewindMilestone2;

// Stores customer-session information. It remains available when an order cart is reset.
internal sealed class Customer
{
    public Customer(string name, string loyaltyNumber, CustomerTier tier)
    {
        Name = name;
        LoyaltyNumber = loyaltyNumber;
        Tier = tier;
    }

    public string Name { get; }
    public string LoyaltyNumber { get; }
    public CustomerTier Tier { get; }
}

// Stores one fixed catalogue product.
internal sealed class Product
{
    public Product(int id, string title, MediaType type, decimal unitPrice)
    {
        Id = id;
        Title = title;
        Type = type;
        UnitPrice = unitPrice;
    }

    public int Id { get; }
    public string Title { get; }
    public MediaType Type { get; }
    public decimal UnitPrice { get; }
}

// Stores a product and quantity in the current order.
internal sealed class OrderLine
{
    public OrderLine(Product product, int quantity)
    {
        Product = product;
        Quantity = quantity;
    }

    public Product Product { get; }
    public int Quantity { get; private set; }

    public void AddQuantity(int additionalQuantity)
    {
        Quantity += additionalQuantity;
    }

    public decimal GetLineTotal()
    {
        return Product.UnitPrice * Quantity;
    }
}

// Carries all checkout amounts so receipt printing does not repeat business calculations.
internal sealed class CheckoutResult
{
    public decimal Subtotal { get; init; }
    public decimal TierRate { get; init; }
    public decimal TierDiscount { get; init; }
    public CouponChoice CouponChoice { get; init; }
    public decimal CouponDiscount { get; init; }
    public string CouponMessage { get; init; } = string.Empty;
    public decimal RewardDiscount { get; init; }
    public string RewardMessage { get; init; } = string.Empty;
    public decimal FinalTotal { get; init; }
}

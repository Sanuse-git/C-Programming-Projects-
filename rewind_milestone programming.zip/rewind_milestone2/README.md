# Rewind Loyalty Cash Register — Programming 161 Milestone 2

This folder contains a **beginner-level .NET 8 console application starter** for the Rewind loyalty-program milestone. The program collects customer details, uses several enum-driven menus, adds VHS tapes, DVDs, and CDs to a cart, applies a transparent loyalty calculation at checkout, prints a receipt, resets the cart, and allows another order or a clean exit.

> **Student action required:** Do not submit this folder unchanged or describe it as your original work. Replace every `[PERSONALISE]` placeholder with truthful group information, confirm the proposed catalogue and loyalty rules with the lecturer or group design, understand every method, and record your own testing.

## Requirements coverage

| Assignment requirement | Implementation evidence |
|---|---|
| C# console application | `RewindMilestone2.csproj` targets .NET 8 and uses no external packages. |
| Initial customer entry | `ReadCustomer()` collects a required name, loyalty number, and tier. |
| Multiple enum menus | `MainMenuChoice`, `MediaType`, `CustomerTier`, `CouponChoice`, and `AfterCheckoutChoice` are actively read by `ReadEnumChoice<T>()`. |
| Reusable methods | Customer entry, validated input, ordering, cart display, calculation, receipt, and reset are separate methods. |
| VHS, DVD, and CD orders | The fixed catalogue has two products in every required media category. |
| Track items and costs | `List<OrderLine>` stores product, quantity, unit price, and line total. Repeated products are merged by quantity. |
| Discounts, coupons, rewards | Tier discount, one optional coupon, and an automatic reward are calculated in a documented sequence. |
| Checkout receipt | The receipt shows customer details, every cart line, subtotal, each benefit, and total due. |
| Loop, reset, and close | A successful checkout calls `cart.Clear()`, then an enum menu offers a new order or exit. Main menu option `0` also exits. |
| Group comments | `Program.cs` contains three clearly marked name/student-number placeholders; major code blocks have explanatory comments. |

## Build and run

Install a [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0), open a terminal in this folder, and run:

```bash
dotnet build
dotnet run
```

The application uses only the .NET standard library. It stores no files and makes no network requests.

## Proposed design assumptions — personalise and confirm

The brief does not provide customer fields, catalogue prices, benefit thresholds, stacking rules, or currency rules. Therefore, the implementation uses the following **proposed project choices**, not assignment facts.

| Topic | Current project choice |
|---|---|
| Customer fields | Required customer name, required loyalty number, and selected Bronze/Silver/Gold tier. **[PERSONALISE: confirm the fields.]** |
| Tier discount | Bronze 0%, Silver 5%, Gold 10% of merchandise subtotal. **[PERSONALISE: confirm rates.]** |
| Coupon | At most one per checkout. R5 off needs an original subtotal of at least R50. A 10% coupon needs at least R100 and applies to the amount after the tier discount. **[PERSONALISE: confirm choices and thresholds.]** |
| Reward | An original subtotal of at least R150 automatically earns and applies one R10 checkout credit. It is not carried to another order. **[PERSONALISE: confirm this rule.]** |
| Calculation order | Subtotal → tier discount → selected eligible coupon → automatic reward → total due, capped at R0.00. |
| Rounding and currency | `decimal` values; monetary results round to two decimal places with `MidpointRounding.AwayFromZero`; display uses South African rand (`en-ZA`). **[PERSONALISE: confirm currency and rounding.]** |
| Product quantities | Positive whole numbers are allowed. Selecting an existing product again increases its quantity. |
| Empty checkout | The program displays a message and returns to the main menu without creating a sale. |
| Reset scope | A successful checkout clears only the cart. The customer remains active for a possible new order. |

### Calculation example

For a **Gold** customer with a **R150.00** subtotal and the **10% coupon**, the tier discount is R15.00. The coupon is then 10% of R135.00, or R13.50. The R10.00 reward applies last. The total due is therefore **R111.50**.

## Catalogue

| Category | Product | Unit price |
|---|---|---:|
| VHS | Retro Adventure | R25.00 |
| VHS | Time Travellers | R30.00 |
| DVD | Future Classics | R50.00 |
| DVD | Comedy Night | R39.99 |
| CD | Synthwave Hits | R25.00 |
| CD | Rock Anthems | R20.00 |

**[PERSONALISE: Replace or confirm every title and price.]** All catalogue data is held in one list near the top of `RewindStore.cs`.

## Small sample run

The following is an abbreviated run. User input is shown after `>`.

```text
Customer name: > Alex Student
Loyalty number: > RW1001

--- SELECT CUSTOMER TIER ---
1. Bronze
2. Silver
3. Gold
Choose an option: > 3

--- MAIN MENU ---
0. Exit
1. Order media
2. View cart
3. Checkout
4. View customer details
Choose an option: > 1

--- MEDIA TYPE ---
0. Back
1. VHS
2. DVD
3. CD
Choose an option: > 2

--- DVD CATALOGUE ---
0. Back
1. Future Classics - R50.00
2. Comedy Night - R39.99
Choose a product: > 1
Quantity: > 3
Added 3 x Future Classics to the cart.
Current subtotal: R150.00

Choose an option: > 3
--- SELECT ONE COUPON ---
0. None
1. R5 off (requires a R50 subtotal)
2. 10% off (requires a R100 subtotal)
Choose an option: > 2
...
Subtotal:                    R150.00
Tier discount (10%):        - R15.00
Coupon discount:            - R13.50
Reward credit:              - R10.00
TOTAL DUE:                   R111.50

Checkout complete. The cart has been reset.
```

The exact thousands and decimal separators follow the installed .NET `en-ZA` culture data, but the numeric values remain the same.

## File guide

| File | Purpose |
|---|---|
| `Program.cs` | Entry point and group-member placeholders. |
| `Enums.cs` | All closed menu-choice sets. |
| `Models.cs` | Customer, product, cart-line, and checkout-result classes. |
| `RewindStore.cs` | User interface, validation, cart, calculations, receipt, reset, and loops. |
| `pseudocode.md` | Language-neutral algorithm aligned with the code. |
| `flowchart.mmd` | Mermaid flowchart aligned with the program control flow. |
| `test-plan.md` | Manual tests, expected calculations, smoke-test evidence, and a submission checklist. |

## Group contribution record

Replace these rows with the **actual** work completed. Every group member should still understand the whole application for the defence.

| Group member | Student number | Actual responsibility |
|---|---|---|
| `[PERSONALISE: Member 1 full name]` | `[PERSONALISE: number]` | `[PERSONALISE: truthful tasks completed]` |
| `[PERSONALISE: Member 2 full name]` | `[PERSONALISE: number]` | `[PERSONALISE: truthful tasks completed]` |
| `[PERSONALISE: Member 3 full name]` | `[PERSONALISE: number]` | `[PERSONALISE: truthful tasks completed]` |

## Defence preparation

Each member should be able to trace one complete customer-to-checkout scenario. They should explain why enums prevent undefined menu actions, how `TryParse` avoids input exceptions, how `List<OrderLine>` retains quantities and prices, why calculations use `decimal`, what order the three benefits follow, and why `cart.Clear()` prevents state from leaking into the next transaction. The 2024 dates printed in the supplied brief may be historical; confirm current presentation arrangements with the lecturer.

## References

The assignment requirements come from the supplied `PRG161[2024-08-07]Milestone2.pdf`. Microsoft documents enums as named integral constants and `Enum.IsDefined` as a way to check whether a value exists in an enum.[1] [2] Microsoft recommends the .NET SDK workflow used by this console project.[3]

[1]: https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/enum "Enumeration types — C# reference"
[2]: https://learn.microsoft.com/en-us/dotnet/api/system.enum.isdefined?view=net-8.0 "Enum.IsDefined Method"
[3]: https://learn.microsoft.com/en-us/dotnet/core/tutorials/with-visual-studio-code "Create a .NET console application using Visual Studio Code"

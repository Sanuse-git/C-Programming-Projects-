namespace RewindMilestone2;

// These enums give each closed set of menu choices a readable name.
internal enum MainMenuChoice
{
    Exit = 0,
    OrderMedia = 1,
    ViewCart = 2,
    Checkout = 3,
    ViewCustomerDetails = 4
}

internal enum MediaType
{
    Back = 0,
    VHS = 1,
    DVD = 2,
    CD = 3
}

internal enum CustomerTier
{
    Bronze = 1,
    Silver = 2,
    Gold = 3
}

internal enum CouponChoice
{
    None = 0,
    FiveRandOff = 1,
    TenPercentOff = 2
}

internal enum AfterCheckoutChoice
{
    Exit = 0,
    StartNewOrder = 1
}

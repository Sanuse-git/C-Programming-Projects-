# Rewind Milestone 2 — Test Plan

This plan verifies the console workflow, input boundaries, cart accounting, loyalty calculations, checkout reset, and submission package. Tests marked **rule-dependent** use the proposed rules in `README.md`; update their expected values if the group changes those rules.

> **Student action required:** Record the tester, date, actual result, and Pass/Fail status during the group’s own execution. Do not present the prepared expected results as evidence that the group performed the tests.

## Test environment and evidence template

| Field | Value to complete |
|---|---|
| Operating system | `[PERSONALISE: test operating system]` |
| .NET SDK | `[PERSONALISE: output of dotnet --version]` |
| Tester and date | `[PERSONALISE: name and date]` |
| Build command | `dotnet build` |
| Run command | `dotnet run` |
| Evidence location | `[PERSONALISE: screenshots, transcript, or notes]` |

For every test, add: **Actual result:** `[PERSONALISE]` and **Status:** `[PERSONALISE: Pass/Fail]`.

## Functional and validation tests

| ID | Test steps | Expected result |
|---|---|---|
| TP-01 | Launch the application. | Title and customer-entry prompts appear before the main menu. No unhandled exception occurs. |
| TP-02 | Enter a valid name, loyalty number, and each valid tier in separate runs. | Each value is accepted and the main menu opens. |
| TP-03 | Submit blank and whitespace-only input for name and loyalty number. | A required-field message appears and the same field is requested again. |
| TP-04 | At each enum menu, enter `abc`, `1.5`, a blank, and an undefined integer. | Each input receives a clear retry message. No action runs and the program does not crash. |
| TP-05 | Select every main-menu option. | Order opens media type; View Cart prints cart; Checkout checks cart; View Customer prints details; Exit closes normally. |
| TP-06 | In Order Media, select Back. Then enter an out-of-range product number. | Back returns without changing the cart. An out-of-range number is rejected. |
| TP-07 | At quantity, enter `0`, `-1`, `two`, then `2`. | The first three values are rejected. Quantity 2 is accepted exactly once. |
| TP-08 | Add one VHS, one DVD, and one CD. View the cart. | All three lines show their correct type, title, quantity, unit price, and line total. |
| TP-09 | Add the same product twice with quantities 2 and 3. | One cart line remains with quantity 5 and a line total of five unit prices. **[PERSONALISE: confirm duplicate rule.]** |
| TP-10 | Select Checkout with a fresh empty cart. | `Empty cart - add an item before checkout.` appears. No coupon menu or receipt is produced. |
| TP-11 | Exit from the main menu with items still in the cart. | The application closes normally without an unintended receipt. |
| TP-12 | Send end-of-input, such as Ctrl+D on Linux, while a prompt is waiting. | The program prints an input-stream message and exits without a null-reference exception. |

## Exact cart-accounting tests

| ID | Cart | Expected merchandise subtotal |
|---|---|---:|
| CA-01 | 1 × Retro Adventure at R25.00 | R25.00 |
| CA-02 | 2 × Future Classics at R50.00 | R100.00 |
| CA-03 | 1 × Comedy Night at R39.99 + 1 × Rock Anthems at R20.00 | R59.99 |
| CA-04 | 1 × Retro Adventure + 1 × Future Classics + 1 × Synthwave Hits | R100.00 |
| CA-05 | 10 × Comedy Night at R39.99 | R399.90 |

## Loyalty calculation tests

These cases follow the current rule order: **subtotal → tier discount → coupon → reward → total due**. Percentage amounts round to two decimals with `MidpointRounding.AwayFromZero`.

| ID | Scenario | Expected deductions and total |
|---|---|---|
| LC-01 | Bronze; R100.00; no coupon | Tier R0.00; coupon R0.00; no reward; **due R100.00**. |
| LC-02 | Silver; R100.00; no coupon | Tier R5.00; coupon R0.00; no reward; **due R95.00**. |
| LC-03 | Gold; R100.00; 10% coupon | Tier R10.00; coupon R9.00 from R90.00; no reward; **due R81.00**. This proves sequential calculation. |
| LC-04 | Bronze; R49.99; R5 coupon | Coupon is ineligible; **due R49.99**. |
| LC-05 | Bronze; R50.00; R5 coupon | Coupon R5.00; **due R45.00**. |
| LC-06 | Bronze; R99.99; 10% coupon | Coupon is ineligible; **due R99.99**. |
| LC-07 | Bronze; R100.00; 10% coupon | Coupon R10.00; **due R90.00**. |
| LC-08 | Bronze; R149.99; no coupon | No reward; **due R149.99**. |
| LC-09 | Bronze; R150.00; no coupon | Reward R10.00; **due R140.00**. |
| LC-10 | Gold; R150.00; 10% coupon | Tier R15.00; coupon R13.50; reward R10.00; **due R111.50**. |
| LC-11 | Silver; R39.99; no coupon | Tier is R2.00 after rounding R1.9995 away from zero; **due R37.99**. |
| LC-12 | No-benefit case: Bronze; R25.00; no coupon | Every deduction is R0.00; **due R25.00**. |

Some boundary totals are easiest to obtain by quantity, for example two R25.00 items for R50.00, two R50.00 items for R100.00, and three R50.00 items for R150.00. A R49.99 case can use R29.99 only if the catalogue is personalised accordingly; otherwise test the nearest reachable ineligible subtotal and record that limitation.

## Checkout, reset, and loop tests

| ID | Test steps | Expected result |
|---|---|---|
| CR-01 | Complete a non-empty checkout. | Receipt identifies customer and every line, then shows subtotal, tier rate/deduction, coupon status/deduction, reward status/deduction, and final total. |
| CR-02 | After CR-01, choose Start a new order and then View Cart. | Customer details remain, but the cart says it is empty. No previous amount or benefit appears. |
| CR-03 | In the second order, add only Rock Anthems and check out. | Receipt contains only Rock Anthems and calculations based only on R20.00. |
| CR-04 | After checkout, choose Exit. | Cart reset confirmation appears before the post-checkout menu, then the application closes normally. |
| CR-05 | In one run, add 20 items while mixing valid and invalid entries, view the cart, check out, begin another order, and exit. | No crash, duplicate action from invalid input, arithmetic drift, or state leakage occurs. |

## Code review and submission acceptance

| ID | Inspection | Acceptance condition |
|---|---|---|
| RV-01 | Search `Enums.cs` and `RewindStore.cs`. | At least five enums are actively used to obtain choices and drive `switch` or decision logic. |
| RV-02 | Inspect `Main()` and menu code. | `Main()` delegates to `Run()`. Input, ordering, subtotal, calculation, receipt, and reset use separate reusable methods. |
| RV-03 | Inspect money declarations. | Prices, rates, and totals use `decimal`; literals use the `m` suffix. |
| RV-04 | Inspect all source headers and comments. | Three real member names/student numbers replace placeholders; comments explain major blocks. |
| RV-05 | Compare code, pseudocode, and flowchart. | Menu options, method behavior, decisions, calculation order, reset, and exits agree. |
| RV-06 | Search the entire folder for `[PERSONALISE]`. | Before submission, no placeholder remains; every replacement is truthful and lecturer-approved. |
| RV-07 | Review contributions. | Each real member and actual responsibility is listed without invented work. |
| RV-08 | Build with warnings reviewed. | Build succeeds with zero errors; warnings are understood and corrected where appropriate. |
| RV-09 | Extract the ZIP into a clean temporary folder; run `dotnet build` and a normal purchase. | ZIP contains the project and required documents; extracted copy builds and runs independently. |
| RV-10 | Conduct a mock defence. | Every member can trace customer entry to checkout, explain their methods, enums, arithmetic, validation, and cart reset. |

## Scripted smoke-test inputs

The following newline-separated input performs a Gold checkout with three R50 DVDs, selects the 10% coupon, starts a new order, confirms the cart is empty, and exits:

```text
Alex Student
RW1001
3
1
2
1
3
3
2
1
2
0
```

Expected key output includes `Current subtotal: R150`, `TOTAL DUE` with `R111,50` or equivalent `en-ZA` separators, `The cart is empty.`, and the normal closing message.

A validation smoke test can begin with blank customer text, invalid tier input, invalid main-menu input, and invalid quantity before supplying valid replacements. Its transcript should contain the three retry messages and still reach a receipt or clean exit.

## Regression rule

After any code or rule change, rebuild and repeat at least TP-04, TP-08, TP-10, LC-03, LC-10, CR-02, and RV-09. Also update `README.md`, `pseudocode.md`, and `flowchart.mmd` so they remain synchronized.

## References

Microsoft documents `Int32.TryParse` as a non-throwing conversion test, `List<T>.Clear` as removal of all list elements, and `decimal` as suitable when decimal precision is required.[1] [2] [3]

[1]: https://learn.microsoft.com/en-us/dotnet/api/system.int32.tryparse?view=net-8.0 "Int32.TryParse Method"
[2]: https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.list-1.clear?view=net-8.0 "List<T>.Clear Method"
[3]: https://learn.microsoft.com/en-us/dotnet/api/system.decimal?view=net-8.0 "Decimal Struct"
